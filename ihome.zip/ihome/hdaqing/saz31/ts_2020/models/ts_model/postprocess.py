from language_model.gpt2.evaluate_pb import GPT2Infer
from preprocess.ppdb import ppdb_preprocess

class PostProcess:
    """
    Need to config flags: ppdb_file
    """
    def __init__(self):
        self.lm = GPT2Infer()


    def postprocess(self,line_src, line_dsts):

        rules_all = []
        for line_dst in line_dsts:
            rules = ppdb_preprocess.get_rules(line_src, line_dst)
            rules_all.extend(rules)

        # Select base sentence
        line_dst = line_dsts[0]
        ori_score = self.lm.get_sents_score(line_dst)

        for rule in rules_all:
            # weight = rule[1]
            rule = rule[0]
            ori_word, tar_word, _ = rule.split("=>")

            line_new = line_dst.replace(ori_word, tar_word)
            new_score = self.lm.get_sents_score(line_new)

            if new_score < ori_score:
                ori_score = new_score
                line_dst = line_new

        return line_dst


