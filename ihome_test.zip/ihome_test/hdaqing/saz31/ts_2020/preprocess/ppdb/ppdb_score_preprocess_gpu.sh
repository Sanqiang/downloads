#!/usr/bin/env bash

#SBATCH --cluster=gpu
#SBATCH --partition=gtx1080
#SBATCH --job-name=ppdb_score_preprocess_gpu
#SBATCH --output=log/ppdb_score_preprocess_gpus_%A_%a.out
#SBATCH --gres=gpu:1
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=2
#SBATCH --time=1-00:00:00
#SBATCH --qos=long
#SBATCH --mem=16g

# Load modules
module restore
export PYTHONPATH="${PYTHONPATH}:/ihome/hdaqing/saz31/ts_2020"

# Run the job
export PYTHONHASHSEED=0
srun python ppdb_score_preprocess.py --cur_thread $SLURM_ARRAY_TASK_ID --num_thread 1000