See https://github.com/google-research/bert/blob/master/README.md
