import os
import html
from multiprocessing import Pool
import sys


LANGUAGES = [
    "zh-CN", "es", "af", "de", "pt", "pl", "hr", "nl", "gl", "el", "it", "lv",
    "sq", "am", "ar", "hy", "az", "eu", "be", "bn", "bs", "bg", "ca", "ceb", "ny", "co", "hr",
    "cs", "da", "nl", "eo", "et", "tl", "fi", "fr", "fy", "ka", "gu", "ht", "ha", "haw",
    "iw", "hi", "hmn", "hu", "is", "ig", "id", "ga", "ja", "jw", "kn", "kk", "km", "ko", "ku", "ky", "lo",
    "la", "lt", "lb", "mk", "mg", "ms", "ml", "mt", "mi", "mr", "mn", "my", "ne", "no", "ps", "fa", "pl",
    "pa", "ro", "ru",  "sm", "gd", "sr", "st", "sn", "sd", "si", "sk", "sl", "so", "su", "sw", "sv",
    "tg", "ta", "te", "th", "tr", "uk", "ur", "uz", "vi", "cy", "xh", "yi", "yo", "zu"
]

COMP_PATH = '/zfs1/hdaqing/saz31/dataset/wikipedia_dump/wiki_output_clean_tokenized_shards/'
SIMP_PATH = '/zfs1/hdaqing/saz31/dataset/wikipedia_dump/wiki_output_trans/nsimp_'
TMP_1_PATH = '/zfs1/hdaqing/saz31/dataset/wikipedia_dump/wiki_output_trans/ntmp1_'
TMP_2_PATH = '/zfs1/hdaqing/saz31/dataset/wikipedia_dump/wiki_output_trans/ntmp2_'
TMP_3_PATH = '/zfs1/hdaqing/saz31/dataset/wikipedia_dump/wiki_output_trans/ntmp3_'


from bs4 import BeautifulSoup
import requests
from requests.exceptions import ConnectionError
import time

GOOGLE_F_URL = 'https://translate.googleusercontent.com/translate_f'

TRUNCATE_PREFIX = '<pre>'
TRUNCATE_SUFFIX = '</pre>'


class Translate:
    def get_proxies_ips(self):
        self.proxies = []
        r = requests.get('https://free-proxy-list.net/')
        html = r.text
        soup = BeautifulSoup(html, 'html.parser')
        rows = soup.find(id="proxylisttable").find_all('tr')
        for row in rows[1:]:
            ip = row.contents[0].text
            port = row.contents[1].text
            proxy = '%s:%s' % (ip, port)
            if proxy not in self.proxies:
                self.proxies.append(proxy)

        self.pid = 0
        print('get %s proxies' % len(self.proxies))

    def get_translate_text(self, file_path, ori_lang, tar_lang, limit_retry=10000):
        params = {'file': open(file_path, 'r'),
                  'hl': 'en',
                  'sl': ori_lang,
                  'tl': tar_lang,
                  'ie': 'UTF-8',
                  'js': 'y',
                  'prev': '_t'}
        retry = limit_retry
        while retry > 0:
            try:
                proxies = {'http': 'http://%s' % self.proxies[self.pid],
                           'https': 'https://%s' % self.proxies[self.pid]}
                r = requests.post(url=GOOGLE_F_URL, files=params,  proxies=proxies, timeout=10)
                if r.status_code != 200:
                    self.pid += 1
                    print('IP failed with %s' % self.pid)
                    print(r)
                    time.sleep(10)
                    retry -= 1
                    continue
                else:
                    break
            except Exception as e:
                print('Connect failed with %s' % self.pid)
                print(e)
                time.sleep(10)
                self.pid += 1
                if self.pid == len(self.proxies)-1:
                    self.get_proxies_ips()
                    self.pid = 0
                retry -= 1
                continue
        if retry <= 0:
            print('Exceed Max trials with file %s' % file_path)
            return None

        text = r.text
        if text.startswith(TRUNCATE_PREFIX):
            text = text[len(TRUNCATE_PREFIX):]
        if text.endswith(TRUNCATE_SUFFIX):
            text = text[:-len(TRUNCATE_SUFFIX)]
        return html.unescape(text)

    def translate(self, path, npath, ori_lang, tar_lang):
        text = self.get_translate_text(path, ori_lang, tar_lang)
        if text is not None:
            f = open(npath, 'w')
            f.write(text)
            f.close()
            return True
        else:
            return False

    def translate_thread(self, _):
        files = os.listdir(COMP_PATH)
        for lang in LANGUAGES:
            for file in files:
                cur_output_parent = SIMP_PATH + lang
                os.makedirs(cur_output_parent, exist_ok=True)
                cur_output_path = os.path.join(cur_output_parent, file)
                if os.path.exists(cur_output_path):
                    continue

                tmp1_parent = TMP_1_PATH + lang
                os.makedirs(tmp1_parent, exist_ok=True)
                tmp1_path = os.path.join(tmp1_parent, file)

                tmp2_parent = TMP_2_PATH + lang
                os.makedirs(tmp2_parent, exist_ok=True)
                tmp2_path = os.path.join(tmp2_parent, file)

                tmp3_parent = TMP_3_PATH + lang
                os.makedirs(tmp3_parent, exist_ok=True)
                tmp3_path = os.path.join(tmp3_parent, file)

                try:
                    cur_ori_path = os.path.join(COMP_PATH, file)

                    lines = open(cur_ori_path).readlines()
                    lines = [line + '\n\n\n' for line in lines]
                    open(tmp1_path, 'w').write(''.join(lines))

                    open(cur_output_path, 'w')  # Place a holder
                    if self.translate(tmp1_path, tmp2_path, ori_lang='en', tar_lang=lang):
                        if self.translate(tmp2_path, tmp3_path, ori_lang=lang, tar_lang='en'):
                            lines = open(tmp3_path).readlines()
                            lines = [line.strip() for line in lines if len(line.strip())>0]
                            if len(lines) > 3:
                                open(cur_output_path, 'w').write('\n'.join(lines))
                                print('Done %s' % cur_output_path)
                                continue
                    # Remove the holder
                    if os.path.exists(cur_output_path):
                        os.remove(cur_output_path)
                except Exception as e:
                    print('Exception of current cur_output_path %s' % cur_output_path)
                    print(e)
                    if os.path.exists(cur_output_path):
                        os.remove(cur_output_path)
                    pass


if __name__ == '__main__':
    tr = Translate()
    tr.get_proxies_ips()
    # tr.translate_thread()
    p = Pool(256)
    while True:
        p.map(tr.translate_thread, range(8192))
