`mnist_tpu.py` can be used to train a simple model on the MNIST dataset using
a Cloud TPU.

See https://cloud.google.com/tpu/docs/quickstart for more details.
