#!/usr/bin/env bash

#SBATCH --cluster=smp
#SBATCH --job-name=generate_tf_example
#SBATCH --output=log/generate_tf_examples_%A_%a.out
#SBATCH --nodes=1
#SBATCH --cpus-per-task=1
#SBATCH --time=1-00:00:00
#SBATCH --qos=long
#SBATCH --mem=32g

# Load modules
module restore
export PYTHONPATH="${PYTHONPATH}:/ihome/hdaqing/saz31/ts_2020"

# Run the job
srun python shuffle_tf_examples.py --cur_shard $SLURM_ARRAY_TASK_ID

