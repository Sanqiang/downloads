import tensorflow as tf
import os
from collections import Counter

flags = tf.flags

flags.DEFINE_string(
    'text_path',
    '/zfs1/hdaqing/saz31/dataset/text_v1_s3_l64/',
    'The path for comp file.')

FLAGS = flags.FLAGS

if __name__ == '__main__':
    cnt = 0
    c_src, c_trg = Counter(), Counter()
    for file in os.listdir(FLAGS.text_path):
        for line in open(os.path.join(FLAGS.text_path, file)):
            if line.startswith('meta:'):
                cnt += 1

                items = line[5:].split()
                src_len = int(items[0])
                trg_len = int(items[1])

                c_src.update([src_len])
                c_trg.update([trg_len])

    print('Cnt: %s' % cnt)
    print('src_c')
    print(c_src.most_common())
    print(c_trg.most_common())
    print(sorted(c_src.most_common()))
    print(sorted(c_trg.most_common()))