import os
import math
import tensorflow as tf
from google.protobuf.json_format import MessageToDict
import base64
from collections import Counter, defaultdict

flags = tf.flags

flags.DEFINE_string(
    'example_path',
    '/zfs1/hdaqing/saz31/dataset/example_v6_val/',
    'The path for ppdb outputs.')

flags.DEFINE_string(
    'vocab_path',
    '/zfs1/hdaqing/saz31/dataset/syn_vocab.txt',
    'The path for ppdb outputs.')

FLAGS = flags.FLAGS

if __name__ == '__main__':
    c = Counter()
    files = os.listdir(FLAGS.example_path)
    for file in files:
        for example in tf.python_io.tf_record_iterator(os.path.join(FLAGS.example_path, file)):
            obj = MessageToDict(tf.train.Example.FromString(example))
            for feature_name in obj["features"]["feature"]:
                if feature_name == 'template_comp' or feature_name == 'template_simp':
                    for field in obj["features"]["feature"][feature_name]:
                        val = base64.b64decode(obj["features"]["feature"][feature_name][field]["value"][0])
                        c.update(val.split())
        print('Done with %s' % file)

    outputs = []
    for syn, _ in c.most_common():
        outputs.append(syn.decode())
    open(FLAGS.vocab_path, 'w').write('\n'.join(outputs))




