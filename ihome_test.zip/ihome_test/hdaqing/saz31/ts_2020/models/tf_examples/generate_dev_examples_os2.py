import tensorflow as tf
import re
from models.utils.control_utils import ControlMethod
from language_model.gpt2.evaluate_pb import GPT2Infer
from models.ts_model.data import BertVocab, _pad_sent, _clean_sent_ids
from collections import Counter, defaultdict, OrderedDict
from nltk.tag import StanfordNERTagger
from nltk.tokenize import word_tokenize

flags = tf.flags

# v2
flags.DEFINE_string(
    'comp_path',
    '/zfs1/hdaqing/saz31/dataset/dev/test.8turkers.tok.norm.ori',
    # "/Users/sanqiang/git/ts/text_simplification_data/server/dev/test.8turkers.tok.norm.ori",
    'The path for comp file.')

flags.DEFINE_string(
    "ref_file",
    "/zfs1/hdaqing/saz31/dataset/dev/dev_data/test_refs/test.8turkers.tok.turk.",
    # "/Users/sanqiang/git/ts/text_simplification_data/server/dev/dev_data/test_refs/test.8turkers.tok.turk.",
    "The path of reference files.")

flags.DEFINE_string(
    'example_output_path',
    '/zfs1/hdaqing/saz31/dataset/dev/test_os2.example',
    # "/Users/sanqiang/git/ts/text_simplification_data/server/output/test.example",
    'The path for ppdb outputs.')

flags.DEFINE_string(
    'text_output_path',
    '/zfs1/hdaqing/saz31/dataset/dev/test.txt',
    # "/Users/sanqiang/git/ts/text_simplification_data/server/output/test.txt",
    'The path for ppdb outputs.')

flags.DEFINE_string(
    'mapper_output_path',
    '/zfs1/hdaqing/saz31/dataset/dev/mapper.txt',
    # "/Users/sanqiang/git/ts/text_simplification_data/server/output/test.txt",
    'The path for ppdb outputs.')

flags.DEFINE_string(
    "ppdb_file",
    "/zfs1/hdaqing/saz31/dataset/ppdb.txt",
    # "/Users/sanqiang/git/ts/text_simplification_data/server/ppdb.txt",
    "The file path of ppdb")

flags.DEFINE_string(
    "ppdb_vocab",
    "/zfs1/hdaqing/saz31/dataset/rule_v7_s3_l64_os/vocab",
    # "/Users/sanqiang/git/ts/text_simplification_data/server/vocab.ppdb",
    "The file path of ppdb vocab generated from train")

flags.DEFINE_string(
    "control_mode", "word_rel:sent_length:word_length:syntax:syn_length:syn_rel:split:ppdb:val", #
    "choice of :")

flags.DEFINE_string(
    "bert_vocab_file",
    "/zfs1/hdaqing/saz31/dataset/vocab/svocab.txt",
    # "/Users/sanqiang/git/ts/svocab.txt",
    "The file path of bert vocab")

flags.DEFINE_string(
    "corenlp_base",
    "/ihome/hdaqing/saz31/corenlp/",
    # "/Users/sanqiang/git/ts/stanford_corenlp/",
    "The file path of bert vocab")

flags.DEFINE_integer(
    "max_src_len", 195,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "max_trg_len", 195,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "max_syntax_src_len", 195,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "max_syntax_trg_len", 195,
    "Maximum length of sentence."
)
flags.DEFINE_integer(
    "max_ppdb_len", 32,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "syntax_level", 3,
    "Maximum depth of syntax tree."
)

FLAGS = flags.FLAGS


def is_number_tryexcept(s):
    """ Returns True is string is a number. """
    if s.startswith("666"):
        return False
    try:
        float(s)
        return True
    except ValueError:
        return False

def check_type(word):
    if word.startswith("LOCATION"):
        return "LOCATION"
    elif word.startswith("ORGANIZATION"):
        return "ORGANIZATION"
    elif word.startswith("PERSON"):
        return "PERSON"
    elif word.startswith("666"):
        return "666"
    else:
        return None

def _bytes_feature(value):
    return tf.train.Feature(bytes_list=tf.train.BytesList(value=value))


def _float_feature(value):
    return tf.train.Feature(float_list=tf.train.FloatList(value=value))


def _int_feature(value):
    return tf.train.Feature(int64_list=tf.train.Int64List(value=value))


def text_process(line):
    line = line.replace("-LRB-", "(")
    line = line.replace("-RRB-", ")")
    line = line.replace("-LSB-", "[")
    line = line.replace("-RSB-", "]")
    line = line.replace("-LCB-", "{")
    line = line.replace("-RCB-", "}")

    line = line.replace("-lrb-", "(")
    line = line.replace("-rrb-", ")")
    line = line.replace("-lsb-", "[")
    line = line.replace("-rsb-", "]")
    line = line.replace("-lcb-", "{")
    line = line.replace("-rcb-", "}")

    line = line.replace("``", "\"")
    line = line.replace("''", "\"")
    line = line.replace("`", "'")
    line = line.replace("'", "'")

    return line


if __name__ == '__main__':
    control_obj = ControlMethod(FLAGS)
    st_base = FLAGS.corenlp_base
    st = StanfordNERTagger(
        st_base + 'classifiers/english.all.3class.distsim.crf.ser.gz',
        st_base + 'stanford-ner.jar',
        encoding='utf-8')

    lm = GPT2Infer()
    vocab = BertVocab(FLAGS.bert_vocab_file)
    texts = []
    mappers = []

    writer = tf.python_io.TFRecordWriter(FLAGS.example_output_path)
    max_seq_len = 0
    max_seq_len_c = Counter()

    all_lines_r = []
    for r_i in range(8):
        lines_r = open(FLAGS.ref_file + str(r_i)).readlines()
        for l_id, line_r in enumerate(lines_r):
            if l_id >= len(all_lines_r):
                all_lines_r.append([])
            all_lines_r[l_id].append(line_r)

    cnt = 0
    for line in open(FLAGS.comp_path):

        if FLAGS.bert_vocab_file:
            comp_ori = text_process(line.strip())
            simp_ori = ""
            comp = text_process(line.lower().strip())

            control_inputss = set()
            assert len(all_lines_r[cnt]) == 8
            for ref_line in all_lines_r[cnt]:
                simp_ori = text_process(ref_line.strip())
                simp = text_process(ref_line.lower().strip())
                sent_vec, word_vec, extra_outputs = control_obj.get_control_vec(
                    comp, simp, comp_ori, simp_ori)
                rule = extra_outputs["rules"]
                control_inputs = extra_outputs["external_inputs"]
                control_inputss.add(control_inputs[0])

            comp_ori_raw = text_process(comp_ori.strip())
            simp_ori_raw = ""
            comp_ori = " ".join(comp_ori_raw.split())
            simp_ori = " ".join(simp_ori_raw.split())

            ner_checker = {}
            reverse_mapper = {}
            counter_reconnect = defaultdict(int)

            # simp
            tokenized_text_simp = word_tokenize(simp_ori)
            classified_text_simp = st.tag(tokenized_text_simp)
            outputs_simp = []
            counter = defaultdict(int)
            for token_pair in classified_text_simp:
                word = token_pair[0].lower()
                if token_pair[1] == "O" and is_number_tryexcept(token_pair[0]):
                    token_pair = (word, "666")

                if token_pair[1] != "O":
                    cur_ner = "%s%s" % (token_pair[1], counter[token_pair[1]])
                    reverse_mapper[cur_ner] = token_pair[0]
                outputs_simp.append(
                    token_pair[0]
                    if token_pair[1] == "O"
                    else cur_ner)
                if token_pair[1] != "O":
                    counter[token_pair[1]] += 1

            # Reconnect
            for i in range(len(outputs_simp)):
                ner_type = check_type(outputs_simp[i])
                if ner_type is not None:
                    cur_ner = "%s%s" % (ner_type, counter_reconnect[ner_type])
                    cur_word = [reverse_mapper[outputs_simp[i]]]
                    outputs_simp[i] = cur_ner
                    counter_reconnect[ner_type] += 1
                    j = i + 1
                    while j < len(outputs_simp):
                        ner_type_j = check_type(outputs_simp[j])
                        if ner_type == ner_type_j:
                            cur_word.append(reverse_mapper[outputs_simp[j]])
                            outputs_simp[j] = ""
                            j += 1
                        else:
                            break
                    if cur_word:
                        cur_word = " ".join(cur_word)
                        ner_checker[cur_word] = cur_ner

            simp_ori = text_process(" ".join([tk for tk in outputs_simp if tk]))
            simp = text_process(" ".join(outputs_simp)).lower()

            # comp
            for cur_word in ner_checker:
                pattern = re.compile(r"\b%s\b" % re.escape(cur_word), re.IGNORECASE)
                comp_ori = pattern.sub(ner_checker[cur_word], comp_ori)
            tokenized_text_comp = word_tokenize(comp_ori)
            classified_text_comp = st.tag(tokenized_text_comp)
            outputs_comp = []
            for token_pair in classified_text_comp:
                word = token_pair[0].lower()
                if token_pair[1] == "O" and is_number_tryexcept(token_pair[0]):
                    token_pair = (word, "666")

                if token_pair[1] != "O":
                    cur_ner = "%s%s" % (token_pair[1], counter[token_pair[1]])
                    reverse_mapper[cur_ner] = token_pair[0]
                outputs_comp.append(
                    token_pair[0]
                    if token_pair[1] == "O"
                    else cur_ner)
                if token_pair[1] != "O":
                    counter[token_pair[1]] += 1

            # Reconnect
            ner_exclude = set(ner_checker.values())
            for i in range(len(outputs_comp)):
                ner_type = check_type(outputs_comp[i])
                if ner_type is not None and outputs_comp[i] in reverse_mapper and outputs_comp[i] not in ner_exclude:
                    cur_ner = "%s%s" % (ner_type, counter_reconnect[ner_type])
                    cur_word = [reverse_mapper[outputs_comp[i]]]
                    outputs_comp[i] = cur_ner
                    counter_reconnect[ner_type] += 1
                    j = i + 1
                    while j < len(outputs_comp):
                        ner_type_j = check_type(outputs_comp[j])
                        if ner_type == ner_type_j:
                            cur_word.append(reverse_mapper[outputs_comp[j]])
                            outputs_comp[j] = ""
                            j += 1
                        else:
                            break
                    if cur_word:
                        cur_word = " ".join(cur_word)
                        ner_checker[cur_word] = cur_ner

            comp_ori = text_process(" ".join([tk for tk in outputs_comp if tk]))
            comp = text_process(" ".join(outputs_comp)).lower()

            final_ner_mapper = []
            for word in ner_checker:
                ner = ner_checker[word]
                final_ner_mapper.append("%s=>%s" % (word, ner))
            final_ner_mapper = "\t".join(final_ner_mapper)

            sent_vec, word_vec, extra_outputs = control_obj.get_control_vec(
                comp, simp, comp_ori, simp_ori)
            control_inputs = extra_outputs["external_inputs"]
            rule = extra_outputs["rules"]
            template_simp = extra_outputs["template_simp_full"]
            template_comp = extra_outputs["template_comp_full"]

            feature = OrderedDict()
            if FLAGS.bert_vocab_file:

                control_ids = vocab.encode_sent(control_inputs[0])
                control_ids_unit = control_ids
                if control_ids_unit:
                    while len(control_ids) + len(control_ids_unit) < FLAGS.max_ppdb_len:
                        control_ids.extend(control_ids_unit)
                control_ids = _pad_sent(
                    control_ids,
                    vocab.pad_id, vocab.eos_id, FLAGS.max_ppdb_len)

                template_comps, template_simps = [[] for _ in range(FLAGS.syntax_level)], \
                                                 [[] for _ in range(FLAGS.syntax_level)]
                template_comp, template_simp = template_comp, template_simp

                for template_comp_tk in template_comp.split():
                    template_comp_tk_stacked_list = template_comp_tk.split('|')
                    for i in range(FLAGS.syntax_level):
                        if i < len(template_comp_tk_stacked_list):
                            template_comps[i].append(template_comp_tk_stacked_list[i])
                        else:
                            template_comps[i].append(
                                template_comp_tk_stacked_list[len(template_comp_tk_stacked_list) - 1])

                for template_simp_tk in template_simp.split():
                    template_simp_tk_stacked_list = template_simp_tk.split('|')
                    for i in range(FLAGS.syntax_level):
                        if i < len(template_simp_tk_stacked_list):
                            template_simps[i].append(template_simp_tk_stacked_list[i])
                        else:
                            template_simps[i].append(
                                template_simp_tk_stacked_list[len(template_simp_tk_stacked_list) - 1])

                src_stacked_ids = vocab.encode_sent_stack(comp)
                trg_stacked_ids = vocab.encode_sent_stack(simp)

                assert len(template_comps[0]) == len(src_stacked_ids)
                template_comp_ids, src_ids = [[] for _ in range(FLAGS.syntax_level)], []

                for i, template_tk in enumerate(src_stacked_ids):
                    for sid in range(len(src_stacked_ids[i])):
                        for l_id, template_comp_tmp in enumerate(template_comps):
                            if l_id == 0:
                                continue
                            src_ids.append(vocab.encode_token(template_comps[l_id][i]))
                        src_ids.append(src_stacked_ids[i][sid])

                # if len(src_ids) > FLAGS.max_src_len:
                #     continue
                len_src = len(src_ids)

                assert len(template_simps[0]) == len(trg_stacked_ids)
                template_simp_ids, trg_ids = [[] for _ in range(FLAGS.syntax_level)], []

                for i, template_tk in enumerate(trg_stacked_ids):
                    for sid in range(len(trg_stacked_ids[i])):
                        for l_id, template_simp_tmp in enumerate(template_simps):
                            if l_id == 0:
                                continue
                            trg_ids.append(vocab.encode_token(template_simps[l_id][i]))
                        trg_ids.append(trg_stacked_ids[i][sid])

                # if len(trg_ids) > FLAGS.max_trg_len:
                #     continue
                len_trg = len(trg_ids)

                for i in range(len(template_simp_ids)):
                    template_simp_ids[i] = _pad_sent(
                        template_simp_ids[i],
                        vocab.pad_id,
                        vocab.eos_id,
                        FLAGS.max_trg_len)

                src_ids, trg_ids = (
                    _pad_sent(
                        src_ids,
                        [vocab.pad_id],
                        [vocab.eos_id],
                        FLAGS.max_src_len),
                    _pad_sent(
                        trg_ids,
                        [vocab.pad_id],
                        [vocab.eos_id],
                        FLAGS.max_trg_len))
                feature['src_ids'] = _int_feature(src_ids)
                feature['trg_ids'] = _int_feature(trg_ids)
                feature['control_ids'] = _int_feature(control_ids)

                final_ner_mapper = []
                for word in ner_checker:
                    ner = ner_checker[word]
                    final_ner_mapper.append("%s=>%s" % (word, ner))
                final_ner_mapper = "\t".join(final_ner_mapper)

            feature['sent_control_vec'] = _float_feature(sent_vec)
            feature['word_control_vec'] = _float_feature(word_vec)

            # feature = {}
            # feature['src_ids'] = _int_feature(src_ids)
            # feature['trg_ids'] = _int_feature(trg_ids)
            # feature['control_ids'] = _int_feature(control_ids)
            # template_comp_ids = [item for sublist in template_comp_ids for item in sublist]
            # template_simp_ids = [item for sublist in template_simp_ids for item in sublist]
            # feature['sent_control_vec'] = _float_feature(sent_vec)
            # feature['word_control_vec'] = _float_feature(word_vec)
        else:
            feature = {
                'src_wds': _bytes_feature([str.encode(line)]),
                'trg_wds': _bytes_feature([str.encode(line)]),
                'template_comp': _bytes_feature([str.encode(extra_outputs["template_comp"])]),
                'template_simp': _bytes_feature([str.encode(extra_outputs["template_comp"])]),
                'template_comp_full': _bytes_feature([str.encode(extra_outputs["template_comp_full"])]),
                'template_simp_full': _bytes_feature([str.encode(extra_outputs["template_comp_full"])]),
                'control_wds': _bytes_feature([str.encode(extra_outputs["external_inputs"])]),
                'sent_control_vec': _float_feature(sent_vec),
                'word_control_vec': _float_feature(word_vec)
            }

        example = tf.train.Example(features=tf.train.Features(feature=feature))
        writer.write(example.SerializeToString())
        texts.append('%s \n %s \n %s \n\n\n' % (line, control_inputs, template_comp))
        mappers.append(final_ner_mapper)
        cnt += 1
    open(FLAGS.text_output_path, "w").write(''.join(texts))
    open(FLAGS.mapper_output_path, "w").write("".join(mappers))

    print('Done:%s' % cnt)