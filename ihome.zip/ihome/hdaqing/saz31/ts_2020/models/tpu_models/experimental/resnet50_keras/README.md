# ResNet-50 #

This directory contains an example of using the experimental Cloud TPU-Keras
integration that was added in TF 1.9. ResNet-50 is a commonly used convolutional
neural network used for image classification. The ResNet-family of models were
introduced for the ImageNet 2015 competition and performed very well there.
