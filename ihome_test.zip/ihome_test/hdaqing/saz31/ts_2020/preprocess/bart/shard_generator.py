"""
Generate shard (only for bart)
"""
import os
import random
import copy
import tensorflow as tf
from multiprocessing import Pool

flags = tf.flags

flags.DEFINE_string(
    "text_dir",
    "/zfs1/hdaqing/saz31/dataset/wikipedia_dump/wiki_output_clean_tokenized/",
    "The output directory where the model checkpoints will be written.")

flags.DEFINE_string(
    "shard_dir",
    "/zfs1/hdaqing/saz31/dataset/wikipedia_dump/wiki_output_clean_tokenized_shards/",
    "The output directory where the model checkpoints will be written.")

FLAGS = flags.FLAGS

if __name__ == '__main__':
    rng = random.Random(1234)

    idx = 0
    outputs = []
    for file in os.listdir(FLAGS.text_dir):
        text_path = os.path.join(FLAGS.text_dir, file)
        for line in open(text_path):
            outputs.append(line.strip())
            if len(outputs) >= 128:
                open(
                    os.path.join(FLAGS.shard_dir, "shard_%s.txt" % idx), "w").write("\n".join(outputs))
                outputs = []
                idx += 1
        print("Cur : %s" % idx)