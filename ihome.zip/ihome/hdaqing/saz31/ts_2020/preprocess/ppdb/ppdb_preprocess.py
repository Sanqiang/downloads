"""Generate PPDB scores for training data
"""
import os
import glob
import tensorflow as tf
from datetime import datetime
from copy import deepcopy
from multiprocessing import Pool
from os.path import exists
from collections import defaultdict
from nltk.translate.bleu_score import sentence_bleu
import operator

flags = tf.flags

flags.DEFINE_string(
    'tags', 'tmp_newsela_1024,tmp_wikilarge_ori_2048,tmp_wikilarge_2048,tmp_wikisplit_8192',
    'tags for process.')
flags.DEFINE_string(
    'comp_path', '/zfs1/hdaqing/saz31/dataset/{{tag}}/ncomp/',
    'The path for complex sentences.')
flags.DEFINE_string(
    'ppdb_output_path', '/zfs1/hdaqing/saz31/dataset/{{tag}}/ppdb3/',
    'The path for ppdb outputs.')
flags.DEFINE_string(
    'tran_path_prefix', '/zfs1/hdaqing/saz31/dataset/{{tag}}/trans_tokenized3/nsimp_',
    'The path for translation prefix file.')

flags.DEFINE_string(
    'post_ppdb_file', '/Users/sanqiang/git/ts/text_simplification_data/ppdb.txt',
    'The path for ppdb file.')

flags.DEFINE_integer("num_thread", 1000, "the dupe factor.")
flags.DEFINE_integer("cur_thread", -1, "the dupe factor.")

FLAGS = flags.FLAGS


def _get_mapper():
    mapper = defaultdict(set)
    for line in tf.gfile.GFile(FLAGS.post_ppdb_file).readlines():
        items = line.split('\t')
        if items:
            mapper[items[0]].add((items[1], float(items[2])))
    return mapper


mapper = _get_mapper()
print('Loaded Mapper.')


def sequence_contain_(seq, targets):
    if len(targets) == 0:
        print('%s_%s' % (seq, targets))
        return False
    if len(targets) > len(seq):
        return False
    for s_i, s in enumerate(seq):
        t_i = 0
        s_loop = s_i
        if s == targets[t_i]:
            while t_i < len(targets) and s_loop < len(seq) and seq[s_loop] == targets[t_i]:
                t_i += 1
                s_loop += 1
            if t_i == len(targets):
                return s_loop-1
    return -1


def get_best_targets_(oriwords, line_dst, line_src, context_window_size=3):
    ress = []
    for tar in mapper[oriwords]:
        tar_words, weight = tar
        pos_dst = sequence_contain_(line_dst, tar_words.split())
        pos_src = sequence_contain_(line_src, tar_words.split())
        if pos_dst > 0 and pos_src == -1:
            # Check context
            pos_src = sequence_contain_(line_src, oriwords.split())

            left_win_src, left_win_dst = set(), set()
            w = 1
            while w <= (1+context_window_size):
                if pos_src - w >= 0:
                    try:
                        left_win_src.add(line_src[pos_src-w])
                    except:
                        pass
                    left_win_src.add(line_src[pos_src - w])
                if pos_dst - w >= 0:
                    try:
                        left_win_dst.add(line_dst[pos_dst - w])
                    except:
                        pass
                    left_win_dst.add(line_dst[pos_dst - w])
                w += 1

            right_win_src, right_win_dst = set(), set()
            w = 0
            while w <= context_window_size:
                if pos_src + len(oriwords.split()) + w < len(line_src):
                    try:
                        right_win_src.add(line_src[pos_src + len(oriwords.split()) + w])
                    except:
                        pass
                    right_win_src.add(line_src[pos_src + len(oriwords.split()) + w])
                if pos_dst + len(tar_words.split()) + w < len(line_dst):
                    try:
                        right_win_dst.add(line_dst[pos_dst + len(tar_words.split()) + w])
                    except:
                        pass
                    right_win_dst.add(line_dst[pos_dst + len(tar_words.split()) + w])
                w += 1
            if len(left_win_src&left_win_dst) == 0 and len(right_win_src&right_win_dst) == 0:
                continue

            res = ('%s=>%s=>%s' % (oriwords, tar_words, weight), weight)
            ress.append(res)
        else:
            continue
    if ress:
        ress.sort(key=operator.itemgetter(1), reverse=True)
        return ress[0]
    else:
        return None


def get_rules(line_src, line_dst):
    rule = set()
    line_src = line_src.split()
    line_dst = line_dst.split()
    bleu = sentence_bleu([line_dst], line_src, weights=[0.5, 0.5])
    # print('bleu:%s' % bleu)
    if bleu >= 0.3:
        for wid in range(len(line_src)):
            # For unigram
            unigram = line_src[wid]
            if unigram in mapper and unigram not in line_dst:
                res = get_best_targets_(unigram, line_dst, line_src)
                if res:
                    rule.add(res[0])

            # For bigram
            if wid + 1 < len(line_src):
                bigram = line_src[wid] + ' ' + line_src[wid + 1]
                if bigram in mapper and sequence_contain_(line_dst, (line_src[wid], line_src[wid+1])) == -1:
                    res = get_best_targets_(bigram, line_dst, line_src)
                    if res:
                        rule.add(res[0])

            # For trigram
            if wid + 2 < len(line_src):
                trigram = line_src[wid] + ' ' + line_src[wid + 1] + ' ' + line_src[wid + 2]
                if trigram in mapper and sequence_contain_(line_dst, (line_src[wid], line_src[wid+1], line_src[wid+2])) == -1:
                    res = get_best_targets_(trigram, line_dst, line_src)
                    if res:
                        rule.add(res[0])
    return rule


def populate_file(comp_file, simp_files):
    """Populate output files based on path_comp and path_simp."""
    f_comp = open(comp_file)
    f_simps = [open(simp_file) for simp_file in simp_files if exists(simp_file)]
    lines_comp = f_comp.readlines()
    lines_simps = [f_simp.readlines() for f_simp in f_simps]
    lines_simps = [lines_simp for lines_simp in lines_simps if abs(len(lines_comp) - len(lines_simp)) <= 1]
    rules = []

    ids = range(len(lines_comp))
    # assert [abs(len(lines_comp) - len(lines_simp)) <= 1 for lines_simp in lines_simps], \
    #     'incorrect lines for file %s' % comp_file
    for id, line_comp in zip(ids, lines_comp):
        rule_tmp = set()
        for lines_simp in lines_simps:
            if id >= len(lines_simp):
                continue
            line_simp = lines_simp[id]
            rule = get_rules(line_comp, line_simp)
            rule_tmp.update(rule)
        rules.append("\t".join(rule_tmp))

    return rules


def generate_score_trans(id, tag):
    os.makedirs(FLAGS.ppdb_output_path.replace("{{tag}}", tag), exist_ok=True)
    comp_file = FLAGS.comp_path.replace("{{tag}}", tag) + 'shard%s.txt' % id
    if not exists(comp_file) or hash(comp_file) % FLAGS.num_thread == FLAGS.cur_thread:
        return
    simp_files = [path + "/shard%s.txt" % id
                  for path in glob.glob(FLAGS.tran_path_prefix.replace("{{tag}}", tag) + "*")]
    ppdb_file = FLAGS.ppdb_output_path.replace("{{tag}}", tag) + 'shard%s.txt' % id

    if exists(ppdb_file):
        return
    f_ppdb = open(ppdb_file, 'w')

    print('Start id:%s' % id)
    s_time = datetime.now()

    rules = populate_file(comp_file, simp_files)
    f_ppdb.write('\n'.join(rules))
    f_ppdb.close()
    time_span = datetime.now() - s_time

    print('Done id:%s with time span %s' % (id, time_span))


if __name__ == '__main__':
    tags = FLAGS.tags.split(',')
    print('Process tags  %s' % tags)
    for tag in tags:
        for i in range(9000):
            generate_score_trans(i, tag)
    # p = Pool(8)
    # p.map(generate_score_trans, range(9000))
