import os, json
import tensorflow as tf

flags = tf.flags

flags.DEFINE_string(
    "prefixs",
    "wikilarge_ori,wikisplit,wikilarge,newsela",
    "The output directory where the model checkpoints will be written.")

flags.DEFINE_string(
    "json_file",
    "/zfs1/hdaqing/saz31/dataset/tmp_wikilarge_ori_2048/lm_score/,"
    "/zfs1/hdaqing/saz31/dataset/tmp_wikisplit_8192/lm_score/,"
    "/zfs1/hdaqing/saz31/dataset/tmp_wikilarge_2048/lm_score/,"
    "/zfs1/hdaqing/saz31/dataset/tmp_newsela_1024/lm_score/",
    "The output directory where the model checkpoints will be written.")

flags.DEFINE_string(
    "keyword", "situated", "keyword you want to search")

flags.DEFINE_bool("search_comp", True, "ONLY search comp sentences.")

FLAGS = flags.FLAGS

def search_main(keyword):
    search_cnt = 0
    json_files = FLAGS.json_file.split(',')
    prefixs = FLAGS.prefixs.split(',')
    assert len(prefixs) == len(json_files)

    for json_file, prefix in zip(json_files, prefixs):
        for idx in range(8192):
            cur_json_file = json_file + 'shard%s.txt' % idx
            if not os.path.exists(cur_json_file):
                continue
            search_cnt += 1
            for line in open(cur_json_file):
                finded = False
                try:
                    if FLAGS.search_comp:
                        obj = json.loads(line)
                        for key in obj:
                            if '[[[COMP]]]' in key and (keyword in key.lower()):
                                finded = True
                    else:
                        finded = keyword in line.lower()

                    if finded:
                        obj = json.loads(line)
                        print("file:%s" % json_file)
                        print(json.dumps(obj, indent=4, sort_keys=True))
                        print('=====')
                except:
                    print('Parse Error:')
                    print(cur_json_file)
    print('Searched %s files.' % search_cnt)

if __name__ == '__main__':
    print("Start search keyword  %s" % FLAGS.keyword)
    search_main(FLAGS.keyword)


