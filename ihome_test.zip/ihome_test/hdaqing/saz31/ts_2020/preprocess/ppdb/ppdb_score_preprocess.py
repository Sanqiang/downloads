"""Generate PPDB scores for training data
"""
import os
import json
import glob
import spacy
import tensorflow as tf
from language_model.gpt2.evaluate_pb import GPT2Infer
from datetime import datetime
from os.path import exists

flags = tf.flags

flags.DEFINE_string(
    'tags', 'tmp_newsela_1024,tmp_wikilarge_ori_2048,tmp_wikilarge_2048,tmp_wikisplit_8192',
    'tags for process.')
flags.DEFINE_string(
    'comp_path', '/zfs1/hdaqing/saz31/dataset/{{tag}}/ncomp/',
    'The path for complex sentences.')
flags.DEFINE_string(
    'score_output_path', '/zfs1/hdaqing/saz31/dataset/{{tag}}/lm_score3/',
    'The path for ppdb outputs.')
flags.DEFINE_string(
    'tran_path_prefix', '/zfs1/hdaqing/saz31/dataset/{{tag}}/trans_tokenized3/nsimp_',
    'The path for translation prefix file.')
flags.DEFINE_string(
    'ppdb_rule_path', '/zfs1/hdaqing/saz31/dataset/{{tag}}/ppdb3/',
    'The path for ppdb outputs.')

flags.DEFINE_integer("num_thread", 1000, "the dupe factor.")
flags.DEFINE_integer("cur_thread", -1, "the dupe factor.")

FLAGS = flags.FLAGS

LM = GPT2Infer()
nlp = spacy.load('en_core_web_lg')


def _get_reorder_sim_score(sent1, sent2):
    sign_src = set()
    for tok in nlp(sent1):
        sign_src.add('%s-%s' % (tok.text, tok.dep_))
    sign_dst = set()
    for tok in nlp(sent2):
        sign_dst.add('%s-%s' % (tok.text, tok.dep_))
    return len(sign_src & sign_dst) / len(sign_src | sign_dst)


def _get_reorder_sim_score2(sent1, sent2):
    template_src = set()
    for token in nlp(sent1):
        if token.head.dep_ == "ROOT":
            template_src.add(token.dep_)
    template_trg = set()
    for token in nlp(sent2):
        if token.head.dep_ == "ROOT":
            template_trg.add(token.dep_)
    return len(template_src & template_trg) / len(template_src | template_trg)


def populate_file(comp_file, simp_files, ppdb_rule_file):
    """Populate output files based on path_comp and path_simp."""
    f_comp = open(comp_file)
    f_simps = [open(simp_file) for simp_file in simp_files if exists(simp_file)]
    f_rules = open(ppdb_rule_file)
    lines_comp = f_comp.readlines()
    lines_simps = [f_simp.readlines() for f_simp in f_simps]
    lines_rules = f_rules.readlines()
    jsons = []

    ids = range(len(lines_comp))
    # assert [abs(len(lines_comp) - len(lines_simp)) <= 1 for lines_simp in lines_simps], \
    #     'incorrect lines for file %s' % comp_file
    lines_simps = [lines_simp for lines_simp in lines_simps
                   if abs(len(lines_comp) - len(lines_simp)) == 0]
    # lines_simps_ignore = [lines_simp fses_comp) - len(lines_simp)) != 0]
    # print('Ignore simple files %s for comp %s', lines_simps_ignore, comp_file)

    for id, line_comp, line_rules in zip(ids, lines_comp, lines_rules):
        line_comp = line_comp.strip()
        rules = [r.split('=>') for r in line_rules.split('\t')]
        json_dict = {}
        tmp_comp_score = LM.get_sents_score(line_comp)
        json_dict["[[[COMP]]] " + line_comp] = tmp_comp_score
        fluent_score, fluent_sent = tmp_comp_score, line_comp
        largest_reorder_sent, largest_reorder_score = None, 99999
        largest_reorder_sent2, largest_reorder_score2 = None, 99999

        for lines_simp in lines_simps:
            if id >= len(lines_simp):
                raise ValueError('unequal lines for  comp_file:%s' % comp_file)
            line_simp = lines_simp[id].strip()
            lang = nlp(line_simp).lang_
            if 'en' != lang or line_simp in json_dict:
                continue

            tmp_simp_score = LM.get_sents_score(line_simp)
            json_dict["[[[SIMP]]] " + line_simp] = tmp_simp_score
            if tmp_simp_score < fluent_score:
                fluent_score = tmp_simp_score
                fluent_sent = line_simp

            if tmp_simp_score <= tmp_comp_score:
                reorder_score = _get_reorder_sim_score(line_comp, line_simp)
                if reorder_score < largest_reorder_score:
                    largest_reorder_sent = line_simp
                    largest_reorder_score = reorder_score

                reorder_score2 = _get_reorder_sim_score2(line_comp, line_simp)
                if reorder_score2 < largest_reorder_score2:
                    largest_reorder_sent2 = line_simp
                    largest_reorder_score2 = reorder_score2


        rev = 0
        for rule in rules:
            if len(rule) < 2:
                continue
            rule_left, rule_right = rule[0], rule[1]
            if rule_left in fluent_sent:
                nsent = fluent_sent.replace(rule_left, rule_right)
                nscore = LM.get_sents_score(nsent)
                if nscore <= fluent_score:
                    fluent_sent = nsent
                    fluent_score = nscore
                    json_dict["[[[REV%s]]] " % rev + str(fluent_sent)] = fluent_score
                    rev += 1

        if largest_reorder_sent is not None:
            rev = 0
            for rule in rules:
                if len(rule) < 2:
                    continue
                rule_left, rule_right = rule[0], rule[1]
                if rule_left in largest_reorder_sent:
                    nsent = largest_reorder_sent.replace(rule_left, rule_right)
                    nscore = LM.get_sents_score(nsent)
                    if nscore <= fluent_score:
                        largest_reorder_sent = nsent
                        fluent_score = nscore
                        json_dict["[[[REV_ORDER%s]]] " % rev + str(largest_reorder_sent)] = fluent_score
                        rev += 1

        if largest_reorder_sent2 is not None:
            rev = 0
            for rule in rules:
                if len(rule) < 2:
                    continue
                rule_left, rule_right = rule[0], rule[1]
                if rule_left in largest_reorder_sent2:
                    nsent = largest_reorder_sent2.replace(rule_left, rule_right)
                    nscore = LM.get_sents_score(nsent)
                    if nscore <= fluent_score:
                        largest_reorder_sent2 = nsent
                        fluent_score = nscore
                        json_dict["[[[REV_1ORDER%s]]] " % rev + str(largest_reorder_sent2)] = fluent_score
                        rev += 1
        jsons.append(json.dumps(json_dict))

    return jsons


def generate_score_trans(id, tag):
    os.makedirs(FLAGS.score_output_path.replace("{{tag}}", tag), exist_ok=True)
    comp_file = FLAGS.comp_path.replace("{{tag}}", tag) + 'shard%s.txt' % id
    if not exists(comp_file):
        return
    if tag == 'tmp_wikisplit_8192' or tag == 'tmp_wikilarge_ori_2048':
        simp_files = [path + "/shard%s.txt" % id
                      for path in glob.glob(FLAGS.tran_path_prefix.replace("{{tag}}", tag) + "*")]
    else:
        simp_files = [path + "/shard%s.txt" % id
                      for path in glob.glob(FLAGS.tran_path_prefix.replace("{{tag}}", tag) + "*2c")]
    score_file = FLAGS.score_output_path.replace("{{tag}}", tag) + 'shard%s.txt' % id
    ppdb_rule_file = FLAGS.ppdb_rule_path.replace("{{tag}}", tag) + 'shard%s.txt' % id

    if exists(score_file):
        return
    f_score = open(score_file, 'w')

    print('Start id with tag :%s %s' % (id, tag))
    s_time = datetime.now()

    jsons = populate_file(comp_file, simp_files, ppdb_rule_file)
    f_score.write('\n'.join(jsons))
    f_score.close()
    time_span = datetime.now() - s_time

    print('Done id:%s with time span %s' % (id, time_span))


if __name__ == '__main__':
    tags = FLAGS.tags.split(',')
    print('Process tags  %s' % tags)
    for tag in tags:
        for i in range(9000):
            if hash(i) % FLAGS.num_thread == FLAGS.cur_thread:
                generate_score_trans(i, tag)
