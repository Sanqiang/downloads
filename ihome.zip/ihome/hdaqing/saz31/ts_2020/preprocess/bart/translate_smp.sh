#!/usr/bin/env bash

#SBATCH --cluster=smp
#SBATCH --job-name=trans
#SBATCH --output=trans.out
#SBATCH --nodes=1
#SBATCH --cpus-per-task=1
#SBATCH --time=0-6:00:00
#SBATCH --qos=short
#SBATCH --mem=16g
#SBATCH --begin=2020-03-13T18:00:00

# Load modules
module restore
export PYTHONPATH="${PYTHONPATH}:/ihome/hdaqing/saz31/ts_2020"

# Run the job
srun python translate_bart.py