import os
import json
import numpy as np
import tensorflow as tf
from language_model.gpt2 import encoder


export_path = '/content/117/1607844790'
model_name = '117'
models_dir = '/content/117、'
max_seq_length= 128
# DEFINE_string(
#     'export_path', '/Users/sanqiang/git/ts/text_simplification_2020/language_model/gpt2/export/1581440582',
#     'The path for export lm model.')
# DEFINE_string(
# #     'export_path', ,
# #     'The path for export lm model.')
# DEFINE_string(
#     'model_name', '1558M',
#     'The name of model, e.g. 774M')
# # DEFINE_string(
# #     'models_dir', '/Users/sanqiang/git/ts/text_simplification_2020/language_model/gpt2/models',
# #     'the folder of model.')
# DEFINE_string(
#     'models_dir', '/content/gpt2/',
#     'the folder of model.')
# DEFINE_integer('max_seq_length', 128,
#                      'The max sequence length of input seuqence.')

# FLAGS = FLAGS


def pad_sequence(seq, pad_id):
    if len(seq) >= max_seq_length:
        seq = seq[:max_seq_length]
    else:
        pad_len = max_seq_length - len(seq)
        seq.extend([pad_id] * pad_len)
    return seq

class GPT2Infer_Shadow:

    def get_sents_score(self, sent):
        return 0.0

class GPT2Infer:
    def __init__(self):
        self.predict_fn = tf.contrib.predictor.from_saved_model(
            export_path)
        models_dir2 = os.path.expanduser(os.path.expandvars(models_dir))
        self.enc = encoder.get_encoder(model_name, models_dir2)
        self.pad_id = self.enc.encoder['<|endoftext|>']

    def get_sents_score(self, sent):
        nsent = pad_sequence(self.enc.encode(sent), self.pad_id)
        examples = []
        feature = {'contexts':
                       tf.train.Feature(int64_list=tf.train.Int64List(value=nsent))}
        example = tf.train.Example(
            features=tf.train.Features(
                feature=feature
            ))
        examples.append(example.SerializeToString())

        predictions = self.predict_fn({'examples': examples})
        return float(predictions['output'])

    def get_sents_score_batch(self, sents):
        examples = []
        for sent in sents:
            nsent = pad_sequence(self.enc.encode(sent), self.pad_id)
            feature = {'contexts':
                           tf.train.Feature(int64_list=tf.train.Int64List(value=nsent))}
            example = tf.train.Example(
                features=tf.train.Features(
                    feature=feature
                ))
            examples.append(example.SerializeToString())

        predictions = self.predict_fn({'examples': examples})
        return float(predictions['output'])


if __name__ == '__main__':
    # print(GPT2Infer().get_sents_score("It is situated at the coast of the baltic sea , where it encloses the city of stralsund ."))
    # print(GPT2Infer().get_sents_score("It is located on the coast of the Baltic Sea and surrounds the city of Stralsund ."))
    # print(GPT2Infer().get_sents_score("It is located on the shores of the Baltic Sea, where it encloses the city of Stralsund."))
    # print(GPT2Infer().get_sents_score("It is located on the Baltic Sea coast, where the city of Stralsund is located ."))
    # print(GPT2Infer().get_sents_score("It is located on the Baltic Sea coast and surrounds the city of Stralsund ."))
    # print(GPT2Infer().get_sents_score("It is situated on the banks of the Baltic sea, where it surrounds the town of Stralsund ."))
    # print(GPT2Infer().get_sents_score("the entry to tsinghua is very competitive to tsinghua . "))
    # print(GPT2Infer().get_sents_score("however , the admission to tsinghua is very competitive ."))
    pass