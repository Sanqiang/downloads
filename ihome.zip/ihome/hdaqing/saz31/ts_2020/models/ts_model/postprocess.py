from language_model.gpt2.evaluate_pb_tmp import GPT2Infer
from preprocess.ppdb import ppdb_preprocess_tmp

class PostProcess:
    """
    Need to config flags: ppdb_file
    """
    def __init__(self):
        self.lm = GPT2Infer()


    def postprocess(self,line_srcs, line_dsts):
        output_dsts = []
        for line_src, line_dst in zip(line_srcs, line_dsts):

            rules_all = []
            for line_dst in line_dsts:
                rules = ppdb_preprocess_tmp.get_rules(line_src, line_dst)
                rules_all.extend(rules)

            # Select base sentence
            min_score = None
            line_dst = None
            for line in line_dsts:
                cur_score = self.lm.get_sents_score(line)
                if min_score is None or cur_score < min_score:
                    min_score = cur_score
                    line_dst = line

            ori_score = self.lm.get_sents_score(line_dst)
            print(rules_all)

            for rule in rules_all:
                # weight = rule[1]
                # rule = rule[0]
                ori_word, tar_word, _ = rule.split("=>")

                line_new = line_dst.replace(ori_word, tar_word)
                new_score = self.lm.get_sents_score(line_new)

                if new_score < ori_score:
                    ori_score = new_score
                    line_dst = line_new
            output_dsts.append(line_dst)

        return output_dsts


