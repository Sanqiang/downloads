"""
Generate clean doc from wikiextractor output
"""
import os
import tensorflow as tf

flags = tf.flags

flags.DEFINE_string(
    "base_dir",
    "/zfs1/hdaqing/saz31/dataset/wikipedia_dump/wiki_output/",
    "The output directory where the model checkpoints will be written.")

flags.DEFINE_string(
    "output_dir",
    "/zfs1/hdaqing/saz31/dataset/wikipedia_dump/wiki_output_clean/",
    "The output directory where the model checkpoints will be written.")

flags.DEFINE_integer(
    "max_files", 1024,
    "Maximum length of files."
)

FLAGS = flags.FLAGS

def process_file(file_path):
    output = []
    for line in open(file_path):
        line = line.strip()
        if line.startswith('<') or not line.endswith('.'):
            continue
        output.append(line)
    return output

if __name__ == '__main__':
    f_id = 0
    for category in os.listdir(FLAGS.base_dir):
        cur_path = os.path.join(FLAGS.base_dir, category)
        for file in os.listdir(cur_path):
            file_path = os.path.join(FLAGS.base_dir, category, file)
            output = process_file(file_path)
            # f_id = str(hash(file_path) % FLAGS.max_files)
            output_path = os.path.join(FLAGS.output_dir, "shard_%s.txt" % f_id)
            f_id += 1
            f = open(output_path, "a")
            f.write('\n'.join(output))
            f.flush()
            print("Done with %s to %s with size %s." % (file_path, output_path, len(output)))


