"""Generate PPDB scores for training data
"""
import os
import glob
import tensorflow as tf
from datetime import datetime
from copy import deepcopy
from multiprocessing import Pool
from os.path import exists
from collections import defaultdict
from nltk.translate.bleu_score import sentence_bleu
import operator

flags = tf.flags

flags.DEFINE_string(
    'tags', 'tmp_newsela_1024,tmp_wikilarge_ori_2048,tmp_wikilarge_2048,tmp_wikisplit_8192',
    'tags for process.')
flags.DEFINE_string(
    'comp_path', '/zfs1/hdaqing/saz31/dataset/{{tag}}/ncomp/',
    'The path for complex sentences.')
flags.DEFINE_string(
    'ppdb_output_path', '/zfs1/hdaqing/saz31/dataset/{{tag}}/ppdb2/',
    'The path for ppdb outputs.')

flags.DEFINE_string(
    'ppdb_file', '/zfs1/hdaqing/saz31/dataset/ppdb/ppdb_rule_l.txt',
    'The path for ppdb file.')

flags.DEFINE_integer("num_thread", 10, "the dupe factor.")
flags.DEFINE_integer("cur_thread", -1, "the dupe factor.")

FLAGS = flags.FLAGS


def _get_mapper():
    mapper = defaultdict(set)
    for line in open(FLAGS.ppdb_file):
        items = line.split('\t')
        if items:
            ori_wd = items[0]
            tar_wds = items[1:]
            for tar_wd in tar_wds:
                mapper[ori_wd].add((tar_wd, 1.0))
    return mapper


mapper = _get_mapper()
print('Loaded Mapper.')


def get_rules(line_src):
    rule = set()
    line_src = line_src.lower()
    for ori_word in mapper:
        if ori_word in line_src:
            for tar_word in mapper[ori_word]:
                rule.add("%s=>%s=>1.0" % (ori_word, tar_word))
    return rule


def populate_file(comp_file):
    """Populate output files based on path_comp and path_simp."""
    f_comp = open(comp_file)
    lines_comp = f_comp.readlines()
    rules = []
    ids = range(len(lines_comp))
    for id, line_comp in zip(ids, lines_comp):
        rule_tmp = set()
        rule = get_rules(line_comp)
        rule_tmp.update(rule)
        rules.append("\t".join(rule_tmp))

    return rules


def generate_score_trans(id, tag):
    if id % FLAGS.num_thread != FLAGS.cur_thread:
        return
    os.makedirs(FLAGS.ppdb_output_path.replace("{{tag}}", tag), exist_ok=True)
    comp_file = FLAGS.comp_path.replace("{{tag}}", tag) + 'shard%s.txt' % id
    if not exists(comp_file):
        return
    ppdb_file = FLAGS.ppdb_output_path.replace("{{tag}}", tag) + 'shard%s.txt' % id

    if exists(ppdb_file):
        return
    f_ppdb = open(ppdb_file, 'w')

    print('Start id:%s' % id)
    s_time = datetime.now()

    rules = populate_file(comp_file)
    f_ppdb.write('\n'.join(rules))
    f_ppdb.close()
    time_span = datetime.now() - s_time

    print('Done id:%s with time span %s' % (id, time_span))


if __name__ == '__main__':
    tags = FLAGS.tags.split(',')
    print('Process tags  %s' % tags)
    for tag in tags:
        for i in range(9000):
            generate_score_trans(i, tag)
    # p = Pool(8)
    # p.map(generate_score_trans, range(9000))
