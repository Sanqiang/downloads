import collections
import os

os.environ['TF_CPP_MIN_VLOG_LEVEL'] = '3'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

import time
import json
import numpy as np
import tensorflow as tf
# import wandb
from models.ts_model.data3 import Data
from models.ts_model.graph import TsGraph
from models.ts_model.graph3 import TsGraph as TsGraph3
from models.utils import ckpt_utils, sari_utils, mteval_bleu, hook_utils, restore_utils
from nltk.translate.bleu_score import sentence_bleu
from tensorflow.contrib import cluster_resolver as contrib_cluster_resolver
from tensorflow.contrib import tpu as contrib_tpu
from models.utils.lamb_optimizer import LAMBOptimizer
from models.tf_examples.generate_examples_oneseq import text_process, _float_feature, _int_feature
import os
import glob
import json
import spacy
import tensorflow as tf
import collections
from models.utils.control_utils import ControlMethod
from language_model.bert import tokenization
from models.ts_model.data import BertVocab, _pad_sent, _clean_sent_ids
from models.ts_model.run3 import model_fn_builder

flags = tf.flags

flags.DEFINE_string(
    "group_name", "text-simplification-syntax",
    "Name of experiment")

flags.DEFINE_string(
    "infer_prefix", "",
    "infer_prefix for file name")

flags.DEFINE_string(
    "group_id", "1",
    "Name of experiment")

flags.DEFINE_string(
    "name", "20200827",
    "Name of experiment")

flags.DEFINE_string(
    "mode", "infer",
    "choice of train/infer/predict")

flags.DEFINE_string(
    "model_mode", "bert_vocab:t2t",
    "mode of model, e.g. gpt2:t2t:bert")

flags.DEFINE_string(
    "init_ckpt_path", None,
    "The Checkpoint for warm start.")

flags.DEFINE_string(
    "exp_dir", "/Users/sanqiang/git/ts/exp/",
    "The output directory where the model checkpoints will be written.")

flags.DEFINE_string(
    "tmp_dir", "/Users/sanqiang/git/ts/exp/",
    "The output directory where the model checkpoints will be written.")

flags.DEFINE_string(
    "train_tfexample",
    "/Users/sanqiang/Downloads/shard_newsela_tiny.example",
    "The path pattern of train tf.Example files.")

flags.DEFINE_integer(
    "num_train_steps", 10000,
    "Number of training step."
)

flags.DEFINE_float(
    "num_warmup_steps", -1,
    "Number of training step."
)

flags.DEFINE_integer(
    "train_batch_size", 8,
    "Size of minibatch."
)

flags.DEFINE_integer(
    "max_src_len", 9,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "max_trg_len", 9,
    "Maximum length of sentence."
)

flags.DEFINE_float(
    "lr", 0.001, "Learning rate.")

flags.DEFINE_float(
    "drop_keep_rate", 0.9, "dropout rate.")

flags.DEFINE_float(
    "syntax_drop_keep_rate", 1.0, "dropout rate.")

flags.DEFINE_integer(
    "beam_search_size", 2,
    "The size of beam search."
)

flags.DEFINE_string(
    "op", "lamb",
    "Name of experiment")
# For predict

flags.DEFINE_string(
    "predict_ckpt",
    None,
    "The file path of ckpt used for prediction.")

flags.DEFINE_string(
    "predict_prefix",
    None,
    "The file path of ckpt used for prediction.")

# For control
flags.DEFINE_float(
    "weight_lm", 1.0, "weight for lm training.")

flags.DEFINE_string(
    "control_mode", "scatter_ppdb:syntax_gen:val:syntax_gen2:syntax_reduce:control:encoder:ppdb:train_control",
    #:control:encoder:ppdb
    "choice of :")

flags.DEFINE_string(
    "control_multiply", "{}",  #:control:encoder:ppdb
    "choice of :")

flags.DEFINE_integer(
    "max_ppdb_len", 3,
    "Maximum length of sentence."
)

flags.DEFINE_string(
    "ppdb_file", "/Users/sanqiang/git/ts/ts_2020_data/ppdb.txt",
    "The file path of ppdb")

flags.DEFINE_string(
    "ppdb_vocab", "/Users/sanqiang/git/ts/ts_2020_data/rule_v3_val/vocab",
    "The file path of ppdb vocab generated from train")

# For BERT
flags.DEFINE_string(
    "bert_ckpt_file",
    None,
    "The file path of bert ckpt")

flags.DEFINE_string(
    "bert_config_file",
    "/Users/sanqiang/git/ts/text_simplification_2020/language_model/bert/uncased_L-12_H-768_A-12/bert_config_test.json",
    "The file path of bert config")

# Syntax
flags.DEFINE_integer(
    "syntax_level", 3,
    "Maximum depth of syntax tree."
)

# For t2t
flags.DEFINE_string("t2t_mode", "", "t2t modes, split by :")

flags.DEFINE_integer(
    "dimension", 16,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "num_heads", 2,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "num_hidden_layers", 2,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "num_syntax_hidden_layers", 2,
    "Maximum length of sentence."
)

# For Inference
flags.DEFINE_integer(
    "num_ref", 3,
    "Number of reference files.")

flags.DEFINE_integer(
    "eval_batch_size", 8,
    "Size of minibatch."
)

# Generate syntax

flags.DEFINE_string(
    "syntax_vocab_file", "/Users/sanqiang/git/ts/text_simplification_data/syntax_all_vocab.txt",
    "The file path of bert vocab")

flags.DEFINE_integer(
    "max_syntax_src_len", 9,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "max_syntax_trg_len", 9,
    "Maximum length of sentence."
)

# For BERT
flags.DEFINE_string(
    "bert_vocab_file", "/Users/sanqiang/git/ts/text_simplification_data/svocab.txt",
    "The file path of bert vocab")

# Won't change a lot
flags.DEFINE_integer(
    "num_cpu", 5,
    "Number of CPUs used for processing data."
)

flags.DEFINE_string(
    "infer_tfexample",
    "/Users/sanqiang/Downloads/shard_newsela_tiny.example",
    "The path pattern of train tf.Example files.")

flags.DEFINE_string(
    "infer_src_file", "/Users/sanqiang/git/ts/text_simplification_edit/data/dummy_data/eval_src.txt",
    "The path of reference files.")

flags.DEFINE_string(
    "infer_ref_file", "/Users/sanqiang/git/ts/text_simplification_edit/data/dummy_data/eval_trg",
    "The path of reference files.")

flags.DEFINE_bool(
    "use_tpu", False,
    "Whether to  use TPU in Colab."
)

flags.DEFINE_bool(
    "uniform_data", False,
    "Whether to uniformly pick up dataset."
)

flags.DEFINE_list(
    "beam_search_size_list", [192, 256, 320],
    "Beam search size list"
)

FLAGS = flags.FLAGS


def create_example(comps, simps, vocab, control_obj, example_file):

    writer = tf.python_io.TFRecordWriter(example_file)

    for comp_ori, simp_ori in zip(comps, simps):
        comp_ori = text_process(comp_ori.strip())
        simp_ori = text_process(simp_ori.strip())
        comp = text_process(comp_ori.lower().strip())
        simp = text_process(simp_ori.lower().strip())

        key = '%s-%s' % (comp, simp)

        sent_vec, word_vec, extra_outputs = control_obj.get_control_vec(
            comp, simp, comp_ori, simp_ori)
        control_inputs = extra_outputs["external_inputs"]
        rule = extra_outputs["rules"]
        template_simp = extra_outputs["template_simp_full"]
        template_comp = extra_outputs["template_comp_full"]

        feature = collections.OrderedDict()
        if FLAGS.bert_vocab_file:

            control_ids = vocab.encode_sent(control_inputs[0])
            control_ids_unit = control_ids
            if control_ids_unit:
                while len(control_ids) + len(control_ids_unit) < FLAGS.max_ppdb_len:
                    control_ids.extend(control_ids_unit)
            control_ids = _pad_sent(
                control_ids,
                vocab.pad_id, vocab.eos_id, FLAGS.max_ppdb_len)

            template_comps, template_simps = [[] for _ in range(FLAGS.syntax_level)], \
                                             [[] for _ in range(FLAGS.syntax_level)]
            template_comp, template_simp = template_comp, template_simp

            for template_comp_tk in template_comp.split():
                template_comp_tk_stacked_list = template_comp_tk.split('|')
                for i in range(FLAGS.syntax_level):
                    if i < len(template_comp_tk_stacked_list):
                        template_comps[i].append(template_comp_tk_stacked_list[i])
                    else:
                        template_comps[i].append(
                            template_comp_tk_stacked_list[len(template_comp_tk_stacked_list) - 1])

            for template_simp_tk in template_simp.split():
                template_simp_tk_stacked_list = template_simp_tk.split('|')
                for i in range(FLAGS.syntax_level):
                    if i < len(template_simp_tk_stacked_list):
                        template_simps[i].append(template_simp_tk_stacked_list[i])
                    else:
                        template_simps[i].append(
                            template_simp_tk_stacked_list[len(template_simp_tk_stacked_list) - 1])

            src_stacked_ids = vocab.encode_sent_stack(comp)
            trg_stacked_ids = vocab.encode_sent_stack(simp)

            assert len(template_comps[0]) == len(src_stacked_ids)
            template_comp_ids, src_ids = [[] for _ in range(FLAGS.syntax_level)], []

            for i, template_tk in enumerate(src_stacked_ids):
                for sid in range(len(src_stacked_ids[i])):
                    for l_id, template_comp_tmp in enumerate(template_comps):
                        if l_id == 0:
                            continue
                        src_ids.append(vocab.encode_token(template_comps[l_id][i]))
                    src_ids.append(src_stacked_ids[i][sid])

            if len(src_ids) > FLAGS.max_src_len:
                continue
            len_src = len(src_ids)

            assert len(template_simps[0]) == len(trg_stacked_ids)
            template_simp_ids, trg_ids = [[] for _ in range(FLAGS.syntax_level)], []

            for i, template_tk in enumerate(trg_stacked_ids):
                for sid in range(len(trg_stacked_ids[i])):
                    for l_id, template_simp_tmp in enumerate(template_simps):
                        if l_id == 0:
                            continue
                        trg_ids.append(vocab.encode_token(template_simps[l_id][i]))
                    trg_ids.append(trg_stacked_ids[i][sid])

            if len(trg_ids) > FLAGS.max_trg_len:
                continue
            len_trg = len(trg_ids)

            for i in range(len(template_simp_ids)):
                template_simp_ids[i] = _pad_sent(
                    template_simp_ids[i],
                    vocab.pad_id,
                    vocab.eos_id,
                    FLAGS.max_trg_len)

            src_ids, trg_ids = (
                _pad_sent(
                    src_ids,
                    [vocab.pad_id for _ in range(len(template_simps) - 1)] + [vocab.pad_id],
                    [vocab.eos_id for _ in range(len(template_simps) - 1)] + [vocab.eos_id],
                    FLAGS.max_src_len),
                _pad_sent(
                    trg_ids,
                    [vocab.pad_id for _ in range(len(template_simps) - 1)] + [vocab.pad_id],
                    [vocab.eos_id for _ in range(len(template_simps) - 1)] + [vocab.eos_id],
                    FLAGS.max_trg_len))
            feature['src_ids'] = _int_feature(src_ids)
            feature['trg_ids'] = _int_feature(trg_ids)
            feature['control_ids'] = _int_feature(control_ids)

        feature['sent_control_vec'] = _float_feature(sent_vec)
        feature['word_control_vec'] = _float_feature(word_vec)

        example = tf.train.Example(features=tf.train.Features(feature=feature))
        writer.write(example.SerializeToString())
    writer.close()

if __name__ == '__main__':
    log_dir = os.path.join(FLAGS.exp_dir, FLAGS.name, 'log')
    model_dir = os.path.join(FLAGS.exp_dir, FLAGS.name, 'model')
    tf.gfile.MakeDirs(log_dir)
    tf.gfile.MakeDirs(model_dir)

    control_obj = ControlMethod(FLAGS)
    vocab = BertVocab(FLAGS.bert_vocab_file)

    example_file = "/content/example"

    comps = ["admission to tsinghua is extremely competitive."]
    simps = [""]

    create_example(comps, simps, vocab, control_obj, example_file)

    FLAGS.model_mode = [v for v in FLAGS.model_mode.split(':') if v]
    FLAGS.control_mode = {v.split('|')[0]: float(v.split('|')[1]) if len(v.split('|')) == 2 else None
                          for v in FLAGS.control_mode.split(':') if v}
    FLAGS.t2t_mode = [v for v in FLAGS.t2t_mode if v]

    FLAGS.infer_tfexample = example_file
    data = Data(FLAGS)

    config = tf.ConfigProto(allow_soft_placement=True, log_device_placement=False)
    config.gpu_options.allow_growth = True
    tpu_cluster_resolver, tpu_config = None, None
    if FLAGS.use_tpu:
        if 'COLAB_TPU_ADDR' not in os.environ:
            print('ERROR: Not connected to a TPU runtime; please see the first cell in this notebook for instructions!')
        else:
            tpu_address = 'grpc://' + os.environ['COLAB_TPU_ADDR']

        tpu_cluster_resolver = contrib_cluster_resolver.TPUClusterResolver(
            tpu_address)
        tpu_config = contrib_tpu.TPUConfig(
            iterations_per_loop=1000,
            num_shards=8)
    run_config = tf.contrib.tpu.RunConfig(
        cluster=tpu_cluster_resolver,
        model_dir=log_dir,
        keep_checkpoint_max=None,
        save_checkpoints_steps=50000,
        session_config=config,
        tpu_config=tpu_config
    )

    model_fn = model_fn_builder(
        data=data,
        init_ckpt_path=FLAGS.init_ckpt_path)
    estimator = tf.contrib.tpu.TPUEstimator(
        model_fn=model_fn,
        config=run_config,
        train_batch_size=FLAGS.train_batch_size,
        eval_batch_size=FLAGS.eval_batch_size,
        predict_batch_size=FLAGS.eval_batch_size,
        use_tpu=FLAGS.use_tpu
    )

    eval_input_fn = data.get_input_fn(
        input_files=FLAGS.infer_tfexample,
        num_cpu_threads=FLAGS.num_cpu,
        is_training=False)

    estimator = tf.contrib.tpu.TPUEstimator(
        model_fn=model_fn,
        config=run_config,
        train_batch_size=FLAGS.train_batch_size,
        eval_batch_size=FLAGS.eval_batch_size,
        predict_batch_size=FLAGS.eval_batch_size,
        use_tpu=FLAGS.use_tpu
    )
    ckpt = ckpt_utils.get_ckpt(model_dir, log_dir)
    results = estimator.predict(
        input_fn=eval_input_fn,
        checkpoint_path=ckpt)
    for inst_id, result in enumerate(results):
        src_wids = [word for step, word in enumerate(list(result['src_ids'])) if step % 3 == 2]
        src_sent, _ = data.vocab.decode_sent(src_wids, return_wps=True)

        gen_trg_ids = list(result['gen_trg_ids'])
        gen_trg_syntax_sent, _ = data.vocab.decode_sent(gen_trg_ids, return_wps=True)
        gen_trg_wids = [word for step, word in enumerate(gen_trg_ids) if step % 3 == 2]
        gen_trg_sent1, _ = data.vocab.decode_sent(gen_trg_wids, return_wps=True)
        gen_trg_sent = " ".join([w for w in gen_trg_sent1.split() if w != "[CLS]" and w != "[SEP]"])

        print(src_sent)
        print(gen_trg_sent)


