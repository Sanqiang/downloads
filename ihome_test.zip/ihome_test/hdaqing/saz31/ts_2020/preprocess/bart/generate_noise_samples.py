"""
Generate noisy src text for dart
"""
import os
import random
import copy
import tensorflow as tf
from models.ts_model.data import BertVocab
import re

flags = tf.flags

flags.DEFINE_string(
    "text_dir",
    "/zfs1/hdaqing/saz31/dataset/wikipedia_dump/wiki_output_clean_tokenized_shards/",
    "The output directory where the model checkpoints will be written.")

flags.DEFINE_string(
    "act_dir",
    "/zfs1/hdaqing/saz31/dataset/wikipedia_dump/wiki_noise/[act]/",
    "The output directory where the model checkpoints will be written.")

flags.DEFINE_string(
    "bert_vocab_file", "/ihome/hdaqing/saz31/ts_2020/language_model/bert/uncased_L-12_H-768_A-12/vocab.txt",
    "The file path of bert vocab")

flags.DEFINE_string(
    "ppdb_file", "/zfs1/hdaqing/saz31/dataset/ppdb.txt",
    "The file path of ppdb")

flags.DEFINE_integer("duplicate_factor", 10, "the dupe factor.")

flags.DEFINE_integer("num_thread", 512, "the dupe factor.")
flags.DEFINE_integer("cur_thread", -1, "the dupe factor.")


FLAGS = flags.FLAGS


class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_word = False

    @staticmethod
    def insert_word(root, tokens):
        node = root
        for token in tokens:
            if token not in node.children:
                node.children[token] = TrieNode()
            node = node.children[token]
        node.is_word = True

    @staticmethod
    def query_word(root, tokens):
        node = root
        for token in tokens:
            if token not in node.children:
                return False
            node = node.children[token]
        return node.is_word

    @staticmethod
    def query_all_word(root, tokens):
        candidate_tokens = []
        node = root
        for end_idx, token in enumerate(tokens):
            if node.is_word:
                candidate_tokens.append(end_idx)
            if token not in node.children:
                break
            node = node.children[token]
        return candidate_tokens


def sequence_contain(seq_a, seq_b):
    i, j = 0, 0
    m, n = len(seq_a), len(seq_b)

    while i < m and j < n:
        i_loop = i
        j = 0

        while seq_a[i_loop] == seq_b[j]:
            i_loop += 1
            j += 1
            if i_loop >= m:
                break
            if j >= n:
                return i
        i += 1

    return -1


def word_shuffle(tokens, rng, duplicate_factor):
    candidate_words = []
    for tid, token in enumerate(tokens):
        if not token.startswith('##'):
            candidate_words.append([token])
        else:
            candidate_words[-1].append(token)

    masked_tokens_list = []
    for _ in range(duplicate_factor):
        rng.shuffle(candidate_words)
        masked_tokens = [tk for word in candidate_words for tk in word]
        masked_tokens_list.append(" ".join(masked_tokens))
    return " [[[SEP]]] ".join(masked_tokens_list)


def phrase_mask(tokens, rng, duplicate_factor):
    candidate_words = []
    for tid, token in enumerate(tokens):
        if not token.startswith('##'):
            candidate_words.append(([token], tid))
        else:
            candidate_words[-1][0].append(token)

    masked_tokens_list = []
    threshold = len(tokens) * 0.3
    for _ in range(duplicate_factor):
        masked_tokens = copy.deepcopy(tokens)
        masked_cnt = 0
        start_pos = rng.randint(0, len(candidate_words)-1)
        for candidate_idx in range(start_pos, len(candidate_words)):
            start_idx = candidate_words[candidate_idx][1]
            for loop_idx in range(len(candidate_words[candidate_idx][0])):
                masked_tokens[start_idx + loop_idx] = '[MASK]'
                masked_cnt += 1

            if masked_cnt >= threshold:
                break
        masked_tokens_list.append(" ".join(masked_tokens))
    return " [[[SEP]]] ".join(masked_tokens_list)


def word_mask(tokens, simp_words_root, rng, duplicate_factor):
    candidate_words = []

    # for simp_word in simp_words:
    #     simp_word_idx = sequence_contain(tokens, simp_word)
    #     if simp_word_idx != -1:
    #         candidate_words.append((simp_word, simp_word_idx))
    #         candidate_words.append((simp_word, simp_word_idx))

    for tid, token in enumerate(tokens):
        if not token.startswith('##'):
            candidate_words.append(([token], tid))
        else:
            candidate_words[-1][0].append(token)

    for tid, token in enumerate(tokens):
        if not token.startswith('##'):
            end_idxs = TrieNode.query_all_word(simp_words_root, tokens[tid:])
            if end_idxs:
                for end_idx in end_idxs:
                    candidate_words.append((tokens[tid: (tid+end_idx)], tid))

    masked_tokens_list = []
    threshold = len(tokens) * 0.3
    for _ in range(duplicate_factor):
        rng.shuffle(candidate_words)
        masked_tokens = copy.deepcopy(tokens)
        masked_cnt = 0
        for candidate_word in candidate_words:
            start_idx = candidate_word[1]
            if masked_tokens[start_idx] == '[MASK]':
                continue

            candiddate_token = candidate_word[0]
            for loop_idx in range(len(candiddate_token)):
                masked_tokens[start_idx + loop_idx] = '[MASK]'
                masked_cnt += 1

            if masked_cnt >= threshold:
                break
        masked_tokens_list.append(" ".join(masked_tokens))

    return " [[[SEP]]] ".join(masked_tokens_list)


def text_process(line):
    line = line.replace("-LRB-", "(")
    line = line.replace("-RRB-", ")")
    line = line.replace("-LSB-", "[")
    line = line.replace("-RSB-", "]")
    line = line.replace("-LCB-", "{")
    line = line.replace("-RCB-", "}")

    line = line.replace("-lrb-", "(")
    line = line.replace("-rrb-", ")")
    line = line.replace("-lsb-", "[")
    line = line.replace("-rsb-", "]")
    line = line.replace("-lcb-", "{")
    line = line.replace("-rcb-", "}")

    line = line.replace("``", "\"")
    line = line.replace("''", "\"")
    line = line.replace("`", "'")
    line = line.replace("'", "'")

    cleanr = re.compile('<.*?>')
    line = re.sub(cleanr, ' ', line)
    line = ' '.join(line.split())

    return line

if __name__ == '__main__':
    assert FLAGS.cur_thread >= 0

    rng = random.Random(1234)

    # simp_words_root = TrieNode()
    # TrieNode.insert_word(simp_words_root, [1, 2, 3, 4])
    # # TrieNode.insert_word(simp_words_root, [1, 2, 3])
    # TrieNode.insert_word(simp_words_root, [1, 2])
    # TrieNode.insert_word(simp_words_root, [5])
    # tokens = [9, 9, 1, 2, 3, 4, 5, 6]
    # for tid, token in enumerate(tokens):
    #     end_idxs = TrieNode.query_all_word(simp_words_root, tokens[tid:])
    #     for e_idx in end_idxs:
    #         print(tokens[tid:(e_idx+tid)])

    for act in ["word_mask", "phrase_mask", "word_shuffle"]:
        os.makedirs(FLAGS.act_dir.replace("[act]", act), exist_ok=True)
    os.makedirs(FLAGS.act_dir.replace("[act]", "ori"), exist_ok=True)

    vocab = BertVocab(FLAGS.bert_vocab_file)
    duplicate_factor = FLAGS.duplicate_factor

    simp_words_root = TrieNode()
    for line in open(FLAGS.ppdb_file):
        simp_word = line.split('\t')[1]
        TrieNode.insert_word(simp_words_root, vocab.tokenizer.tokenize(simp_word))

    for file in os.listdir(FLAGS.text_dir):
        input_path = os.path.join(FLAGS.text_dir, file)
        output_src_path = os.path.join(FLAGS.act_dir.replace("[act]", "ori"), file)

        if (hash(output_src_path) % FLAGS.num_thread) != FLAGS.cur_thread:
            continue
        if os.path.exists(output_src_path):
            continue

        lines =open(input_path).readlines()
        nlines = []
        for line in lines:
            line = text_process(line)
            nlines.append(line)

        open(output_src_path, 'w').write('\n'.join(nlines))

        for act in ["word_mask", "phrase_mask", "word_shuffle"]:
            output_path = os.path.join(FLAGS.act_dir.replace("[act]", act), file)

            if os.path.exists(output_path):
                continue
            f = open(output_path, 'w')

            outputs = []
            for line in lines:
                tokens = vocab.tokenizer.tokenize(line)
                if act == "word_mask":
                    outputs.append(
                        word_mask(
                            tokens, simp_words_root, rng, duplicate_factor))
                elif act == "phrase_mask":
                    outputs.append(
                        phrase_mask(
                            tokens, rng, duplicate_factor))
                elif act == "word_shuffle":
                    outputs.append(
                        word_shuffle(
                            tokens, rng, duplicate_factor))

            f.write('\n'.join(outputs))
            f.close()

