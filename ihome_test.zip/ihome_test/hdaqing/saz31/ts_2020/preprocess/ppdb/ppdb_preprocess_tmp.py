"""Generate PPDB scores for training data
"""
import os
import glob
import tensorflow as tf
from datetime import datetime
from copy import deepcopy
from multiprocessing import Pool
from os.path import exists
from collections import defaultdict
from nltk.translate.bleu_score import sentence_bleu
import operator

flags = tf.flags


flags.DEFINE_integer("num_thread", 1000, "the dupe factor.")
flags.DEFINE_integer("cur_thread", -1, "the dupe factor.")

FLAGS = flags.FLAGS

def _validate_word(word):
    for ch in word:
        if ch.isalpha() or ch == " ":
            continue
        else:
            return False
    return True


def _get_mapper():
    mapper = defaultdict(set)
    # for line in tf.gfile.GFile("gs://text_simplification/data/common/ppdb.txt").readlines():
    for line in tf.gfile.GFile("gs://text_simplification/data/common/ppdb.txt").readlines():
        items = line.split('\t')
        if items and _validate_word(items[0]) and _validate_word(items[1]):
            mapper[items[0]].add((items[1], float(items[2])))
    print('Loaded Mapper with size %s' % len(mapper))
    return mapper

def _get_small_mapper():
    small_mapper = defaultdict(set)
    for line in tf.gfile.GFile("gs://text_simplification/data/common/ppdb_small.txt").readlines():
        items = line.split('\t')
        if items and _validate_word(items[0]) and _validate_word(items[1]):
            small_mapper[items[0]].add((items[1], float(items[2])))
    print('Loaded Small Mapper with size %s' % len(small_mapper))
    return small_mapper


mapper = _get_mapper()
small_mapper = _get_small_mapper()
print('Loaded Mapper %s and Small Mapper %s.' % (len(mapper), len(small_mapper)))


def sequence_contain_(seq, targets):
    if len(targets) == 0:
        print('%s_%s' % (seq, targets))
        return False
    if len(targets) > len(seq):
        return False
    for s_i, s in enumerate(seq):
        t_i = 0
        s_loop = s_i
        if s == targets[t_i]:
            while t_i < len(targets) and s_loop < len(seq) and seq[s_loop] == targets[t_i]:
                t_i += 1
                s_loop += 1
            if t_i == len(targets):
                return s_loop-1
    return -1


def get_best_targets_(oriwords, line_dst, line_src, context_window_size=3, tmp_mapper=None):
    ress = []
    for tar in tmp_mapper[oriwords]:
        tar_words, weight = tar
        pos_dst = sequence_contain_(line_dst, tar_words.split())
        pos_src = sequence_contain_(line_src, tar_words.split())
        if pos_dst > 0 and pos_src == -1:
            # Check context
            pos_src = sequence_contain_(line_src, oriwords.split())

            left_win_src, left_win_dst = set(), set()
            w = 1
            while w <= (1+context_window_size):
                if pos_src - w >= 0:
                    try:
                        left_win_src.add(line_src[pos_src-w])
                    except:
                        pass
                    left_win_src.add(line_src[pos_src - w])
                if pos_dst - w >= 0:
                    try:
                        left_win_dst.add(line_dst[pos_dst - w])
                    except:
                        pass
                    left_win_dst.add(line_dst[pos_dst - w])
                w += 1

            right_win_src, right_win_dst = set(), set()
            w = 0
            while w <= context_window_size:
                if pos_src + len(oriwords.split()) + w < len(line_src):
                    try:
                        right_win_src.add(line_src[pos_src + len(oriwords.split()) + w])
                    except:
                        pass
                    right_win_src.add(line_src[pos_src + len(oriwords.split()) + w])
                if pos_dst + len(tar_words.split()) + w < len(line_dst):
                    try:
                        right_win_dst.add(line_dst[pos_dst + len(tar_words.split()) + w])
                    except:
                        pass
                    right_win_dst.add(line_dst[pos_dst + len(tar_words.split()) + w])
                w += 1
            if len(left_win_src&left_win_dst) == 0 and len(right_win_src&right_win_dst) == 0:
                continue

            res = ('%s=>%s=>%s' % (oriwords, tar_words, weight), weight)
            ress.append(res)
        else:
            continue
    if ress:
        ress.sort(key=operator.itemgetter(1), reverse=True)
        return ress[0]
    else:
        return None


def get_rules_all(line_src, line_dst):
    return get_rules(line_src, line_dst, mapper)


def get_rules_small(line_src, line_dst):
    return get_rules(line_src, line_dst, small_mapper)


def get_rules(line_src, line_dst, tmp_mapper=None):
    rule = set()
    if type(line_src) == str:
        line_src = line_src.split()
    if type(line_dst) == str:
        line_dst = line_dst.split()
    bleu = sentence_bleu([line_dst], line_src, weights=[0.5, 0.5])
    # print('bleu:%s' % bleu)
    if bleu >= 0.3:
        for wid in range(len(line_src)):
            # For unigram
            unigram = line_src[wid]
            if unigram in tmp_mapper and unigram not in line_dst:
                res = get_best_targets_(unigram, line_dst, line_src, tmp_mapper=tmp_mapper)
                if res:
                    rule.add(res[0])

            # For bigram
            if wid + 1 < len(line_src):
                bigram = line_src[wid] + ' ' + line_src[wid + 1]
                if bigram in tmp_mapper and sequence_contain_(line_dst, (line_src[wid], line_src[wid+1])) == -1:
                    res = get_best_targets_(bigram, line_dst, line_src, tmp_mapper=tmp_mapper)
                    if res:
                        rule.add(res[0])

            # For trigram
            if wid + 2 < len(line_src):
                trigram = line_src[wid] + ' ' + line_src[wid + 1] + ' ' + line_src[wid + 2]
                if trigram in tmp_mapper and sequence_contain_(line_dst, (line_src[wid], line_src[wid+1], line_src[wid+2])) == -1:
                    res = get_best_targets_(trigram, line_dst, line_src, tmp_mapper=tmp_mapper)
                    if res:
                        rule.add(res[0])
    return rule
