#!/usr/bin/env bash

#SBATCH --cluster=smp
#SBATCH --job-name=generate_data
#SBATCH --output=log/generate_data_%A_%a.out
#SBATCH --nodes=1
#SBATCH --cpus-per-task=1
#SBATCH --time=3-00:00:00
#SBATCH --qos=long
#SBATCH --mem=32g

# Load modules
module restore
export PYTHONPATH="${PYTHONPATH}:/ihome/hdaqing/saz31/ts_2020"

# Run the job
export PYTHONHASHSEED=0
srun python generate_data_rules.py --cur_thread $SLURM_ARRAY_TASK_ID --num_thread 10