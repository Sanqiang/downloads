from models.ts_model.data2 import  Data
import tensorflow as tf

flags = tf.flags

flags.DEFINE_string(
    "group_name", "text-simplification-syntax",
    "Name of experiment")

flags.DEFINE_string(
    "infer_prefix", "",
    "infer_prefix for file name")

flags.DEFINE_string(
    "group_id", "1",
    "Name of experiment")

flags.DEFINE_string(
    "name", "20200325",
    "Name of experiment")

flags.DEFINE_string(
    "mode", "infer",
    "choice of train/infer/predict")

flags.DEFINE_string(
    "model_mode", "bert_vocab:t2t",
    "mode of model, e.g. gpt2:t2t:bert")

flags.DEFINE_string(
    "init_ckpt_path", None,
    "The Checkpoint for warm start.")

flags.DEFINE_string(
    "exp_dir", "/Users/sanqiang/git/ts/exp/",
    "The output directory where the model checkpoints will be written.")

flags.DEFINE_string(
    "tmp_dir", "/Users/sanqiang/git/ts/exp/",
    "The output directory where the model checkpoints will be written.")

flags.DEFINE_string(
    "train_tfexample",
    "/Users/sanqiang/git/ts/text_simplification_data/example/shard_newsela_505.example",
    "The path pattern of train tf.Example files.")

flags.DEFINE_integer(
    "num_train_steps", 10000,
    "Number of training step."
)

flags.DEFINE_float(
    "num_warmup_steps", -1,
    "Number of training step."
)

flags.DEFINE_integer(
    "train_batch_size", 10,
    "Size of minibatch."
)

flags.DEFINE_integer(
    "max_src_len", 64,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "max_trg_len", 64,
    "Maximum length of sentence."
)

flags.DEFINE_float(
    "lr", 0.001, "Learning rate.")

flags.DEFINE_float(
    "drop_keep_rate", 0.9, "dropout rate.")

flags.DEFINE_integer(
    "beam_search_size", 10,
    "The size of beam search."
)

flags.DEFINE_string(
    "op", "lamb",
    "Name of experiment")
# For predict

flags.DEFINE_string(
    "predict_ckpt",
    None,
    "The file path of ckpt used for prediction.")

flags.DEFINE_string(
    "predict_prefix",
    None,
    "The file path of ckpt used for prediction.")

# For control
flags.DEFINE_string(
    "control_mode", "scatter_ppdb:syntax_gen:val:syntax_gen2:syntax_reduce:control:encoder:ppdb:train_control",
    #:control:encoder:ppdb
    "choice of :")

flags.DEFINE_string(
    "control_multiply", "{}",  #:control:encoder:ppdb
    "choice of :")

flags.DEFINE_integer(
    "max_ppdb_len", 128,
    "Maximum length of sentence."
)

flags.DEFINE_string(
    "ppdb_file", "/Users/sanqiang/git/ts/ts_2020_data/ppdb.txt",
    "The file path of ppdb")

flags.DEFINE_string(
    "ppdb_vocab", "/Users/sanqiang/git/ts/ts_2020_data/rule_v3_val/vocab",
    "The file path of ppdb vocab generated from train")

# For BERT
flags.DEFINE_string(
    "bert_ckpt_file",
    None,
    "The file path of bert ckpt")

flags.DEFINE_string(
    "bert_config_file",
    "/Users/sanqiang/git/ts/text_simplification_2020/language_model/bert/uncased_L-12_H-768_A-12/bert_config_test.json",
    "The file path of bert config")

# Syntax
flags.DEFINE_integer(
    "syntax_level", 3,
    "Maximum depth of syntax tree."
)

# For t2t
flags.DEFINE_string("t2t_mode", "", "t2t modes, split by :")

flags.DEFINE_integer(
    "dimension", 32,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "num_heads", 2,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "num_hidden_layers", 2,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "num_syntax_hidden_layers", 2,
    "Maximum length of sentence."
)

# For Inference
flags.DEFINE_integer(
    "num_ref", 3,
    "Number of reference files.")

flags.DEFINE_integer(
    "eval_batch_size", 2,
    "Size of minibatch."
)

# Generate syntax

flags.DEFINE_string(
    "syntax_vocab_file", "/Users/sanqiang/git/ts/text_simplification_data/syntax_all_vocab.txt",
    "The file path of bert vocab")

flags.DEFINE_integer(
    "max_syntax_src_len", 64,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "max_syntax_trg_len", 64,
    "Maximum length of sentence."
)

# For BERT
flags.DEFINE_string(
    "bert_vocab_file", "/Users/sanqiang/git/ts/text_simplification_data/vocab.txt",
    "The file path of bert vocab")

# For GPT2
# flags.DEFINE_string(
#     "gpt2_ckpt_path", None,
#     "The Checkpoint for warm start of GPT2.")
#
# flags.DEFINE_string(
#     'model_name', '117M',
#     'The name of model, e.g. 774M')
#
# flags.DEFINE_string(
#     'models_dir', '/Users/sanqiang/git/ts/text_simplification_2020/language_model/gpt2/models',
#     'the folder of model.')

# Won't change a lot
flags.DEFINE_integer(
    "num_cpu", 5,
    "Number of CPUs used for processing data."
)

flags.DEFINE_string(
    "infer_tfexample",
    "/Users/sanqiang/git/ts/text_simplification_data/example/shard_newsela_505.example",
    "The path pattern of train tf.Example files.")

flags.DEFINE_string(
    "infer_src_file", "/Users/sanqiang/git/ts/text_simplification_edit/data/dummy_data/eval_src.txt",
    "The path of reference files.")

flags.DEFINE_string(
    "infer_ref_file", "/Users/sanqiang/git/ts/text_simplification_edit/data/dummy_data/eval_trg",
    "The path of reference files.")

flags.DEFINE_bool(
    "use_tpu", False,
    "Whether to  use TPU in Colab."
)

flags.DEFINE_bool(
    "uniform_data", False,
    "Whether to uniformly pick up dataset."
)

FLAGS = flags.FLAGS

data = Data(FLAGS)
# print(data.vocab.encode_sent("I am good 哈哈 ."))
src_line = "I am good R1 R2 ."
gen_trg_sent = "I am good [UNK] [UNK]"
src_sent, src_wps = data.vocab.decode_sent([1045, 2572, 2204, 100, 100, 1012], return_wps=True)
src_ori_sent = src_line.lower().split()
src_wps_set = set(src_wps)
unk_replace = []
for tk in src_ori_sent:
    if tk not in src_wps_set:
        unk_replace.append(tk)
gen_trg_sent_list = gen_trg_sent.split()
unk_id = 0
if unk_replace:
    for tid in range(len(gen_trg_sent_list)):
        if gen_trg_sent_list[tid] == "[UNK]":
            gen_trg_sent_list[tid] = unk_replace[unk_id]
            unk_id += 1
            unk_id %= len(unk_replace)
gen_trg_sent = " ".join(gen_trg_sent_list)
print(gen_trg_sent)