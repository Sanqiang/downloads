import os
import random
import tensorflow as tf
from models.utils.control_utils import ControlMethod
from models.ts_model.data import BertVocab, _pad_sent

flags = tf.flags

flags.DEFINE_integer("number_output", 100000, "number of files output")

flags.DEFINE_string(
    "src_folder_prefix",
    "/zfs1/hdaqing/saz31/dataset/wikipedia_dump/wiki_noise/",
    "The trg files prefix.")

flags.DEFINE_string(
    "trg_folder",
    "/zfs1/hdaqing/saz31/dataset/wikipedia_dump/wiki_noise/ori/",
    "The src file.")

flags.DEFINE_string(
    "output_example_folder",
    "/zfs1/hdaqing/saz31/dataset/dart_example_v1_l64_s3/",
    "The exmaple file.")

flags.DEFINE_string(
    "output_text_folder",
    "/zfs1/hdaqing/saz31/dataset/dart_text_v1_l64_s3/",
    "The text report file.")

flags.DEFINE_string(
    "bert_vocab_file", "/ihome/hdaqing/saz31/ts_2020/language_model/bert/uncased_L-12_H-768_A-12/vocab.txt",
    "The file path of bert vocab")

flags.DEFINE_string(
    "syntax_vocab_file", "/zfs1/hdaqing/saz31/dataset/syntax_all_vocab.txt",
    "The file path of bert vocab")

# flags.DEFINE_string(
#     "bert_vocab_file", "/Users/sanqiang/git/ts/text_simplification_data/vocab.txt",
#     "The file path of bert vocab")
#
# flags.DEFINE_string(
#     "syntax_vocab_file", "/Users/sanqiang/git/ts/ts_2020_data/syntax_all_vocab.txt",
#     "The file path of bert vocab")

flags.DEFINE_string(
    "ppdb_file", "/zfs1/hdaqing/saz31/dataset/notexisted_ppdb.txt",
    "The file path of ppdb")

flags.DEFINE_string(
    "ppdb_vocab", "/zfs1/hdaqing/saz31/dataset/rule_v_not_existed/vocab",
    "The file path of ppdb vocab generated from train")

flags.DEFINE_string(
    "control_mode", "word_rel:sent_length:word_length:syntax:syn_length:syn_rel:split:ppdb:val",
    "choice of :")

flags.DEFINE_integer(
    "max_src_len", 64,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "max_trg_len", 64,
    "Maximum length of sentence."
)

flags.DEFINE_integer(
    "syntax_level", 3,
    "Maximum depth of syntax tree."
)

flags.DEFINE_integer("num_thread", 512, "the dupe factor.")
flags.DEFINE_integer("cur_thread", -1, "the dupe factor.")

FLAGS = flags.FLAGS


def _float_feature(value):
    return tf.train.Feature(float_list=tf.train.FloatList(value=value))


def _int_feature(value):
    return tf.train.Feature(int64_list=tf.train.Int64List(value=value))


def text_process(line):
    line = line.replace("-LRB-", "(")
    line = line.replace("-RRB-", ")")
    line = line.replace("-LSB-", "[")
    line = line.replace("-RSB-", "]")
    line = line.replace("-LCB-", "{")
    line = line.replace("-RCB-", "}")

    line = line.replace("-lrb-", "(")
    line = line.replace("-rrb-", ")")
    line = line.replace("-lsb-", "[")
    line = line.replace("-rsb-", "]")
    line = line.replace("-lcb-", "{")
    line = line.replace("-rcb-", "}")

    line = line.replace("``", "\"")
    line = line.replace("''", "\"")
    line = line.replace("`", "'")
    line = line.replace("'", "'")

    return line


def process_file(src_path, trg_path, features, texts, vocab, syntax_vocab, control_obj, rng):
    src_lines = open(src_path, 'r', errors='ignore').readlines()
    trg_lines = open(trg_path, 'r', errors='ignore').readlines()
    if len(src_lines) == len(trg_lines):
        for src_sents, trg_sent in zip(src_lines, trg_lines):

            simp = text_process(trg_sent.lower().strip())
            simp_ori = text_process(trg_sent.strip())

            try:
                sent_vec, word_vec, extra_outputs = control_obj.get_control_vec(
                    simp, simp, simp_ori, simp_ori)
                template_simp = extra_outputs["template_simp_full"]
            except:
                print(simp_ori)
                continue

            # Parse template_simp (split by |)
            template_simps = [[] for _ in range(FLAGS.syntax_level)]
            for template_simp_tk in template_simp.split():
                template_simp_tk_stacked_list = template_simp_tk.split('|')
                for i in range(FLAGS.syntax_level):
                    if i < len(template_simp_tk_stacked_list):
                        template_simps[i].append(template_simp_tk_stacked_list[i])
                    else:
                        template_simps[i].append(
                            template_simp_tk_stacked_list[len(template_simp_tk_stacked_list) - 1])

            trg_stacked_ids = vocab.encode_sent_stack(simp)
            assert len(template_simps[0]) == len(trg_stacked_ids)
            for l in range(len(template_simps)):
                assert len(template_simps[0]) ==  len(template_simps[l])

            template_simp_ids, trg_ids = [[] for _ in range(FLAGS.syntax_level)], []

            for l_id, template_simp_tmp in enumerate(template_simps):
                for i, template_tk in enumerate(template_simp_tmp):
                    if l_id == 0:
                        trg_ids.extend(trg_stacked_ids[i])
                    template_simp_ids[l_id].extend([
                        syntax_vocab.encode_token(template_tk) for _ in range(len(trg_stacked_ids[i]))])
                assert len(trg_ids) == len(template_simp_ids[l_id])

            if len(trg_ids) > FLAGS.max_trg_len:
                continue

            for i in range(len(template_simp_ids)):
                template_simp_ids[i] = _pad_sent(
                    template_simp_ids[i],
                    syntax_vocab.pad_id, syntax_vocab.eos_id, FLAGS.max_trg_len)
            template_simp_ids = [item for sublist in template_simp_ids for item in sublist]

            trg_ids = _pad_sent(
                    trg_ids, vocab.pad_id, vocab.eos_id, FLAGS.max_trg_len)


            for src_sent in src_sents.split('[[[SEP]]]'):
                feature = {}

                comp = src_sent
                try:
                    src_ids = [vocab.encode_token(i) for i in comp.split()]
                except Exception as e:
                    print(e)
                    print(comp.split())

                if len(src_ids) > FLAGS.max_src_len:
                    continue

                src_ids = _pad_sent(
                    src_ids, vocab.pad_id, vocab.eos_id, FLAGS.max_src_len)

                feature['src_ids'] = _int_feature(src_ids)
                feature['trg_ids'] = _int_feature(trg_ids)
                # feature['control_ids'] = _int_feature([0] * 128)
                # feature['template_comp_ids'] = _int_feature([0] * FLAGS.max_src_len)
                feature['template_simp_ids'] = _int_feature(template_simp_ids)
                # feature['control_vec'] = _float_feature([0.0] * 8)

                features.append(feature)
                texts.append(
                    'src:%s \t trg:%s \n %s \n' % (src_sent, trg_sent, template_simp))
        combs = list(zip(features, texts))
        rng.shuffle(combs)
        examples = [comb[0] for comb in combs]
        texts = [comb[1] for comb in combs]
        return examples, texts
    else:
        print('Unequall lines for %s' % trg_path)
        open('/zfs1/hdaqing/saz31/dataset/wikipedia_dump/err.log', 'a').write(
            'Unequall lines for %s' % trg_path)
        return [], []


if __name__ == '__main__':
    vocab = BertVocab(FLAGS.bert_vocab_file)
    syntax_vocab = BertVocab(FLAGS.syntax_vocab_file)
    control_obj = ControlMethod(FLAGS)

    rng = random.Random(1234)

    assert FLAGS.cur_thread >= 0

    # process_file(
    #     "/Users/sanqiang/Downloads/test.txt", "/Users/sanqiang/Downloads/test.txt", [], [], vocab, syntax_vocab, control_obj, rng)

    acts = ['phrase_mask', 'word_mask']
    for act in acts:
        os.makedirs(FLAGS.output_example_folder + act, exist_ok=True)
        os.makedirs(FLAGS.output_text_folder + act, exist_ok=True)

        for oid in range(FLAGS.number_output):
            if oid % FLAGS.num_thread != FLAGS.cur_thread:
                continue

            output_example_path = os.path.join(FLAGS.output_example_folder, act, 'shard_%s.example' % oid)
            if os.path.exists(output_example_path):
                continue

            trg_files = [file for file in os.listdir(FLAGS.trg_folder) if hash(file) % FLAGS.number_output == oid]
            print("Size:%s" % len(trg_files))

            writer = tf.python_io.TFRecordWriter(output_example_path)

            output_text_path = os.path.join(FLAGS.output_text_folder, act, 'shard_%s.text' % oid)
            texts, features = [], []

            for trg_file in trg_files:
                trg_path = os.path.join(FLAGS.trg_folder, trg_file)
                src_path = os.path.join(FLAGS.src_folder_prefix, act, trg_file)
                tmp_features, tmp_texts = process_file(
                    src_path, trg_path, features, texts, vocab, syntax_vocab, control_obj, rng)
                features.extend(tmp_features)
                texts.extend(tmp_texts)
                print('Generate %s samples from %s' % (len(features), trg_file))

            combs = list(zip(features, texts))
            rng.shuffle(combs)
            examples = [comb[0] for comb in combs]
            texts = [comb[1] for comb in combs]
            for feature in features:
                example = tf.train.Example(features=tf.train.Features(feature=feature))
                writer.write(example.SerializeToString())
            writer.close()
            open(output_text_path, 'w').write('\n'.join(texts))


