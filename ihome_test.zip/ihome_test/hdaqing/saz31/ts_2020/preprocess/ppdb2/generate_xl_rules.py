import re
import tensorflow as tf
from collections import defaultdict

flags = tf.flags

flags.DEFINE_string(
    "ppdb_file",
    "/zfs1/hdaqing/saz31/dataset/ppdb/ppdb-2.0-xxxl-all",
    "The trg files prefix.")

flags.DEFINE_string(
    "output_file",
    "/zfs1/hdaqing/saz31/dataset/ppdb/ppdb_rule2.txt",
    "The trg files prefix.")

FLAGS = flags.FLAGS

def process(wd):
    cleanr = re.compile(r"\[.*?\]")
    wd = re.sub(cleanr, '', wd)
    return wd.strip()

if __name__ == '__main__':

    mapper = defaultdict(set)

    idx = 0
    for line in open(FLAGS.ppdb_file):
        items = line.split('|||')
        src_wd = process(items[1])
        trg_wd = process(items[2])

        mapper[src_wd].add(trg_wd)
        mapper[trg_wd].add(src_wd)

        idx += 1

        if idx % 100000 == 0:
            print('Progress %s' % (idx/145655922))

    outputs = []
    for key in mapper:
        outputs.append('%s\t%s' % (key, '\t'.join(mapper[key])))
        # for val in mapper[key]:
        #     outputs.append('%s\t%s' % (key, val))
    open(FLAGS.output_file, 'w').write('\n'.join(outputs))



