
syn_set =set()
for line in open('/Users/sanqiang/git/ts/ts_2020_data/syntax_vocab.txt').readlines():
    syn_set.add(line.strip())

outputs = []
for line in open('/Users/sanqiang/git/ts/ts_2020_data/syn_vocab.txt').readlines():
    syn = line.strip()
    if syn in syn_set:
        syn_set.remove(syn)
    outputs.append(syn)

for syn in syn_set:
    outputs.append(syn)
open('/Users/sanqiang/git/ts/ts_2020_data/syntax_all_vocab.txt', 'w').write('\n'.join(outputs))