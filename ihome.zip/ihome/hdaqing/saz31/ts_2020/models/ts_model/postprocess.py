from language_model.gpt2.evaluate_pb_tmp import GPT2Infer
from preprocess.ppdb import ppdb_preprocess_tmp
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from collections import Counter
import tensorflow_hub as hub
import matplotlib.pyplot as plt
import numpy as np
import time

class PostProcess:
    """
    Need to config flags: ppdb_file
    """

    def __init__(self):
        self.lm = GPT2Infer()
        self.stemmer = PorterStemmer()
        self.stop_words = set([self.stemmer.stem(w) for w in set(stopwords.words('english'))])
        # module_url = "https://tfhub.dev/google/universal-sentence-encoder-large/5"  # @param ["https://tfhub.dev/google/universal-sentence-encoder/4", "https://tfhub.dev/google/universal-sentence-encoder-large/5"]
        # self.model = hub.load(module_url)
        print("Load postprocess module.")

    # def sentence_embed(self, input):
    #     def embed(input):
    #         return self.model(input)
    #     return embed(input)
    #
    # def get_ut_sim(self, s1, s2):
    #     embeds = self.sentence_embed([s1, s2])
    #     return np.inner(embeds, embeds)[0][1]

    def check(self, line_src, line_dst, rules_all):
        line_src_wds = Counter([self.stemmer.stem(w) for w in line_src.split()])
        line_dst_wds = Counter([self.stemmer.stem(w) for w in line_dst.split()])
        if 3 * len(line_dst_wds) < len(line_src_wds):
            return  -999999
        # if '[unk]' in line_dst_wds:
        #     return -999999 * line_dst_wds['[unk]']
        candidates = Counter()
        for rule in rules_all:
            ori_word, tar_word, _ = rule.split("=>")
            for tk in tar_word.split():
                candidates.update([self.stemmer.stem(tk)])

        # for line_src_wd in line_src_wds:
        #     for tar in ppdb_preprocess_tmp.mapper[line_src_wd]:
        #         tar_words, weight = tar
        #         for tar_word in tar_words.split():
        #             candidates.add(tar_word)
        #             print('%s=>%s' % (line_src_wd, tar_words))
        # print(candidates)

        score = 0
        new_words = line_dst_wds - line_src_wds - candidates
        for new_word in new_words:
            if new_word in self.stop_words:
                pass
            elif new_word == "[unk]":
                score -= 999999
            else:
                score -= 1
        if score <= -999999:
            print(line_src_wds)
            print(line_dst_wds)
        return score

    def postprocess(self, line_srcs, line_dstses):
        output_dsts = []
        for line_src, line_dsts in zip(line_srcs, line_dstses):
            print("=====\nline_src:%s" % line_src)

            rules_all = []
            line_dsts = list(set(line_dsts))
            # print('%s line dsts' % len(line_dsts))

            # t1_start = time.perf_counter()
            for line_dst in line_dsts:
                rules = ppdb_preprocess_tmp.get_rules(line_src, line_dst)
                rules_all.extend(rules)
            # t1_stop = time.perf_counter()
            # print("TIME for rule build:", t1_stop - t1_start)

            # Select base sentence
            min_score, min_check_score = None, None
            line_dst = None
            for line in line_dsts:
                # t1_start = time.perf_counter()
                cur_score = self.lm.get_sents_score(line)
                # t1_stop = time.perf_counter()
                # print("TIME for lm infer:", t1_stop - t1_start)

                # t1_start = time.perf_counter()
                # sim_score = self.get_ut_sim(line, line_src)
                # t1_stop = time.perf_counter()
                # print("TIME for sim infer:", t1_stop - t1_start)
                sim_score = 1.0

                # t1_start = time.perf_counter()
                cur_check_score = self.check(line_src, line, rules_all)
                # t1_stop = time.perf_counter()
                # print("TIME for check infer:", t1_stop - t1_start)

                if min_score is None or (cur_score < min_score and cur_check_score >= min_check_score and sim_score >= 0.8):
                    min_score = cur_score
                    min_check_score = cur_check_score
                    line_dst = line
                    print("cur simple:%s with lm score %s, and check score %s and sim_score:%s" % (line_dst, min_score, min_check_score, sim_score))
                elif sim_score < 0.8:
                    print("nonsim simple:%s with lm score %s, and check score %s and sim_score:%s" % (line_dst, min_score, min_check_score, sim_score))
                # else:
                #     print("non simple:%s with lm score %s, and check score %s" % (line_dst, min_score, min_check_score))

            ori_score = self.lm.get_sents_score(line_dst)

            for rule in rules_all:
                # weight = rule[1]
                # rule = rule[0]
                ori_word, tar_word, _ = rule.split("=>")

                line_new = line_dst.replace(ori_word, tar_word)
                new_score = self.lm.get_sents_score(line_new)
                # sim_score = self.get_ut_sim(line_new, line_src)
                sim_score = 1.0

                if new_score < ori_score and sim_score >= 0.8:
                    ori_score = new_score
                    line_dst = line_new

                    print("cur simple:%s with rule %s" % (line_new, rule))
            output_dsts.append(line_dst)

        return output_dsts


